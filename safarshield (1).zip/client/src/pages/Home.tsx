import { useMemo, useState } from "react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertCircle,
  ArrowRight,
  Check,
  ChevronLeft,
  FileImage,
  Fingerprint,
  Globe2,
  History,
  Link2,
  LockKeyhole,
  Menu,
  Mic2,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";

const fields = [
  ["recruiterName", "Recruiter / agency", "ایجنسی یا ریکروٹر"],
  ["licenceNumber", "OEP licence", "OEP لائسنس"],
  ["jobTitle", "Job title", "جاب ٹائٹل"],
  ["country", "Country", "ملک"],
  ["salary", "Salary", "تنخواہ"],
  ["fee", "Requested fee", "درخواست کردہ فیس"],
  ["deadline", "Deadline", "آخری تاریخ"],
  ["urgencyClaim", "Urgency claim", "جلدی کا دعویٰ"],
] as const;

type Claims = Record<(typeof fields)[number][0], string>;
type Evidence = {
  field: string;
  label: string;
  claim: string;
  status: "MATCH" | "CONFLICT" | "NOT_FOUND" | "NOT_CHECKED";
  explanation: string;
  sourceUrl: string;
  sourceTitle: string;
  retrievedAt: string;
};
type GeminiState =
  | "connected"
  | "missing_key"
  | "privacy_blocked"
  | "model_unavailable"
  | "request_failed"
  | "invalid_response";
type SourceRetrieval = {
  sourceMode: "live" | "fallback" | "live_unavailable_fallback" | "demo";
  result: "success" | "not_found" | "blocked" | "unavailable" | "skipped";
  queryValue?: string;
  sourceUrl: string;
  sourceTitle: string;
  responseStatus?: number;
  detail: string;
  retrievedAt: string;
  fallbackUsed: boolean;
};
const blankClaims = (): Claims =>
  Object.fromEntries(fields.map(([key]) => [key, ""])) as Claims;

const copy = {
  ur: {
    subtitle: "پردائیگی سے پہلے ثبوت دیکھیں",
    hero: "بیرونِ ملک نوکری کے دعوے کو سمجھیں — محفوظ طریقے سے",
    intro:
      "ClearPath آپ کے نوکری کے کاغذات، اسکرین شاٹس اور وائس نوٹس کو منظم کر کے سرکاری BEOE ذرائع کے ساتھ شفاف موازنہ کرتا ہے۔ یہ کسی نوکری کو اصلی یا جعلی قرار نہیں دیتا۔",
    newCase: "نیا کیس شروع کریں",
    tryDemo: "ڈیمو کیس آزمائیں",
    history: "محفوظ کیسز",
    step1: "ان پٹ",
    step2: "تصدیق",
    step3: "ثبوت",
    uploadTitle: "آفر ڈاکیومنٹ یا اسکرین شاٹ",
    uploadHelp: "PDF، JPG، PNG — صرف فرضی یا ریڈیکٹ کیا ہوا ڈیٹا استعمال کریں",
    typedTitle: "یا تفصیلات لکھیں",
    typedPlaceholder:
      "مثال: Recruiter: Bright Future Recruiting\nOEP licence: OEP-1823/LHR\nJob: Electrician\nCountry: Qatar\nSalary: 1800 QAR\nFee: PKR 180,000",
    extract: "تفصیلات نکالیں",
    reviewTitle: "نکالی گئی تفصیلات کی تصدیق کریں",
    reviewHelp: "AI کی ہر فیلڈ کو چیک کریں، غلطی درست کریں، پھر ثبوت چیک کریں۔",
    runCheck: "ثبوت چیک کریں",
    evidenceTitle: "شفاف ثبوت رپورٹ",
    source: "ماخذ",
    snapshot: "Snapshot",
    save: "کیس محفوظ کریں",
    signIn: "محفوظ کرنے کے لیے سائن اِن کریں",
    reset: "نیا کیس",
    safe: "محفوظ ڈیزائن",
  },
  en: {
    subtitle: "Review evidence before paying",
    hero: "Make overseas-job offers easier to verify — safely",
    intro:
      "ClearPath organizes job documents, screenshots, and voice notes into a transparent comparison with official BEOE sources. It never declares an offer genuine or fraudulent.",
    newCase: "Start a new case",
    tryDemo: "Try a demo case",
    history: "Saved cases",
    step1: "Intake",
    step2: "Confirm",
    step3: "Evidence",
    uploadTitle: "Offer document or screenshot",
    uploadHelp: "PDF, JPG, PNG — use synthetic or redacted data only",
    typedTitle: "Or type the details",
    typedPlaceholder:
      "Example: Recruiter: Bright Future Recruiting\nOEP licence: OEP-1823/LHR\nJob: Electrician\nCountry: Qatar\nSalary: 1800 QAR\nFee: PKR 180,000",
    extract: "Extract details",
    reviewTitle: "Confirm extracted details",
    reviewHelp:
      "Review every AI-extracted field, correct anything needed, then check evidence.",
    runCheck: "Check evidence",
    evidenceTitle: "Transparent evidence report",
    source: "Source",
    snapshot: "Snapshot",
    save: "Save case",
    signIn: "Sign in to save",
    reset: "New case",
    safe: "Safety-first design",
  },
  pa: {
    subtitle: "ادائیگی توں پہلاں ثبوت ویکھو",
    hero: "بیرون ملک نوکری دے دعوے نوں محفوظ طریقے نال سمجھو",
    intro:
      "ClearPath نوکری دے کاغذات، سکرین شاٹس تے وائس نوٹس نوں سرکاری BEOE ذرائع نال صاف موازنہ کردا اے۔ ایہہ نوکری نوں اصلی یا جعلی قرار نہیں دیندا۔",
    newCase: "نواں کیس شروع کرو",
    tryDemo: "ڈیمو کیس ویکھو",
    history: "محفوظ کیسز",
    step1: "ان پٹ",
    step2: "تصدیق",
    step3: "ثبوت",
    uploadTitle: "آفر ڈاکیومنٹ یا سکرین شاٹ",
    uploadHelp: "PDF، JPG، PNG — صرف فرضی یا ریڈیکٹ کیتا ڈیٹا استعمال کرو",
    typedTitle: "یا تفصیل لکھو",
    typedPlaceholder:
      "مثال: Recruiter: Bright Future Recruiting\nOEP licence: OEP-1823/LHR\nJob: Electrician\nCountry: Qatar\nSalary: 1800 QAR\nFee: PKR 180,000",
    extract: "تفصیل کڈھو",
    reviewTitle: "کڈھیاں تفصیلات دی تصدیق کرو",
    reviewHelp: "AI دی ہر فیلڈ ویکھو، غلطی ٹھیک کرو، فیر ثبوت چیک کرو۔",
    runCheck: "ثبوت چیک کرو",
    evidenceTitle: "صاف ثبوت رپورٹ",
    source: "ماخذ",
    snapshot: "Snapshot",
    save: "کیس محفوظ کرو",
    signIn: "محفوظ کرن لئی سائن اِن کرو",
    reset: "نواں کیس",
    safe: "محفوظ ڈیزائن",
  },
} as const;

function statusLabel(status: Evidence["status"]) {
  return {
    MATCH: "MATCH",
    CONFLICT: "CONFLICT",
    NOT_FOUND: "NOT FOUND",
    NOT_CHECKED: "NOT CHECKED",
  }[status];
}
function statusClass(status: Evidence["status"]) {
  return {
    MATCH: "status-match",
    CONFLICT: "status-conflict",
    NOT_FOUND: "status-missing",
    NOT_CHECKED: "status-neutral",
  }[status];
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [language, setLanguage] = useState<"ur" | "en" | "pa">("ur");
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [claims, setClaims] = useState<Claims>(blankClaims());
  const [typedText, setTypedText] = useState("");
  const [fileName, setFileName] = useState("");
  const [fileData, setFileData] = useState<string | undefined>();
  const [provider, setProvider] = useState<"gemini" | "fallback" | null>(null);
  const [providerState, setProviderState] = useState<GeminiState | null>(null);
  const [evidence, setEvidence] = useState<Evidence[]>([]);
  const [actionCard, setActionCard] = useState<{
    headline: string;
    summary: string;
    next: string;
    sourceUrl: string;
    sourceTitle: string;
    retrievedAt: string;
    reviewedAt: string;
    sourceMode: SourceRetrieval["sourceMode"];
    sourceResult: SourceRetrieval["result"];
    fallbackUsed: boolean;
    sourceDetail: string;
  } | null>(null);
  const [retrieval, setRetrieval] = useState<SourceRetrieval | null>(null);
  const [aiExplanation, setAiExplanation] = useState("");
  const [explanationProvider, setExplanationProvider] = useState<
    "gemini" | "fallback" | null
  >(null);
  const [explanationState, setExplanationState] = useState<GeminiState | null>(
    null
  );
  const [explanationNote, setExplanationNote] = useState("");
  const [title, setTitle] = useState("Overseas job offer review");
  const [busy, setBusy] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [redactedConfirmed, setRedactedConfirmed] = useState(false);
  const [extractionNote, setExtractionNote] = useState("");
  const [selectedCaseId, setSelectedCaseId] = useState<number | null>(null);
  const [voiceSpeaking, setVoiceSpeaking] = useState(false);
  const t = copy[language];
  const demos = trpc.clearpath.demos.useQuery();
  const providerStatus = trpc.clearpath.providerStatus.useQuery();
  const extract = trpc.clearpath.extract.useMutation();
  const explain = trpc.clearpath.explain.useMutation();
  const check = trpc.clearpath.check.useMutation();
  const save = trpc.clearpath.saveCase.useMutation();
  const upload = trpc.clearpath.uploadDocument.useMutation();
  const deleteCase = trpc.clearpath.deleteCase.useMutation();
  const deleteDocument = trpc.clearpath.deleteDocument.useMutation();
  const cases = trpc.clearpath.cases.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const selectedCase = trpc.clearpath.caseById.useQuery(
    { id: selectedCaseId ?? 0 },
    { enabled: isAuthenticated && selectedCaseId !== null }
  );
  const setField = (key: keyof Claims, value: string) =>
    setClaims(current => ({ ...current, [key]: value }));
  const hasClaims = useMemo(
    () => Object.values(claims).some(Boolean),
    [claims]
  );

  function handleFile(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 5_000_000)
      return toast.error("Please choose a file under 5 MB.");
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setFileData(String(reader.result));
    reader.readAsDataURL(file);
  }
  async function handleExtract() {
    if (!typedText && !fileData)
      return toast.error("Add typed details or a document first.");
    setBusy(true);
    try {
      const result = await extract.mutateAsync({
        text: typedText,
        imageDataUrl: fileData,
        redactedConfirmed,
      });
      setClaims(result.claims as Claims);
      setProvider(result.provider);
      setProviderState(result.state);
      setExtractionNote(result.note ?? "");
      setConfirmed(false);
      setStep(2);
      toast.success(
        result.provider === "gemini"
          ? "Gemini extraction complete."
          : "Fallback extraction ready for review."
      );
    } catch {
      toast.error(
        "Extraction failed. You can still use a demo case or type fields manually."
      );
    } finally {
      setBusy(false);
    }
  }
  function useDemo(id?: string) {
    const item = demos.data?.find(d => d.id === id) ?? demos.data?.[0];
    if (!item) return;
    setClaims(item.claims as Claims);
    setTitle(item.title);
    setProvider("fallback");
    setProviderState("connected");
    setExtractionNote(
      "Synthetic demo snapshot loaded. No live government record was queried."
    );
    setConfirmed(false);
    setStep(2);
    toast.success("Synthetic demo loaded. Review every field before checking.");
  }
  async function handleCheck() {
    if (!confirmed)
      return toast.error(
        "Confirm that you reviewed every extracted field first."
      );
    if (!hasClaims)
      return toast.error("Confirm at least one extracted field first.");
    setBusy(true);
    try {
      const result = await check.mutateAsync({ claims, language });
      setClaims(result.claims as Claims);
      setEvidence(result.evidence as Evidence[]);
      setActionCard(result.actionCard);
      setRetrieval(result.retrieval as SourceRetrieval);
      setAiExplanation("");
      setExplanationProvider(null);
      setExplanationState(null);
      setExplanationNote("");
      setStep(3);
    } finally {
      setBusy(false);
    }
  }
  async function handleExplain() {
    if (!actionCard) return;
    setBusy(true);
    try {
      const result = await explain.mutateAsync({
        claims,
        evidence,
        actionCard,
        language,
      });
      setAiExplanation(result.explanation);
      setExplanationProvider(result.provider);
      setExplanationState(result.state);
      setExplanationNote(result.note);
    } catch {
      toast.error(
        "AI explanation was unavailable; the evidence card remains available."
      );
    } finally {
      setBusy(false);
    }
  }
  async function handleSave() {
    if (!isAuthenticated) return startLogin();
    if (!actionCard) return;
    try {
      const result = await save.mutateAsync({
        title,
        language,
        sourceMode: fileName ? "upload" : typedText ? "typed" : "demo",
        claims,
        evidence,
        actionCard,
        retrieval: retrieval ?? undefined,
      });
      if (result.saved) {
        if (fileData && fileName && result.id)
          await upload.mutateAsync({
            caseId: result.id,
            fileName,
            mimeType: "application/octet-stream",
            dataUrl: fileData,
          });
        toast.success("Case saved to your private history.");
        await cases.refetch();
      }
    } catch {
      toast.error("Could not save this case yet.");
    }
  }
  function reset() {
    setStep(1);
    setClaims(blankClaims());
    setConfirmed(false);
    setRedactedConfirmed(false);
    setExtractionNote("");
    setTypedText("");
    setFileName("");
    setFileData(undefined);
    setEvidence([]);
    setActionCard(null);
    setRetrieval(null);
    setAiExplanation("");
    setExplanationProvider(null);
    setExplanationState(null);
    setExplanationNote("");
    setProvider(null);
    setProviderState(null);
    setTitle("Overseas job offer review");
  }
  function speakActionCard() {
    if (!actionCard) return;
    if (!("speechSynthesis" in window))
      return toast.info("Voice playback is not available in this browser.");
    window.speechSynthesis.cancel();
    const speech = new SpeechSynthesisUtterance(
      `${actionCard.headline}. ${actionCard.summary}. ${actionCard.next}`
    );
    speech.lang =
      language === "ur" ? "ur-PK" : language === "pa" ? "pa-IN" : "en-US";
    speech.onstart = () => setVoiceSpeaking(true);
    speech.onend = () => setVoiceSpeaking(false);
    speech.onerror = () => setVoiceSpeaking(false);
    window.speechSynthesis.speak(speech);
    toast.success(
      language === "en"
        ? "Playing the explanation aloud."
        : "نتیجہ آواز میں سنایا جا رہا ہے۔"
    );
  }

  return (
    <div className="app-shell" dir={language === "en" ? "ltr" : "rtl"}>
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark">
            <ShieldCheck size={20} strokeWidth={2.5} />
          </div>
          <div>
            <div className="brand-name">ClearPath</div>
            <div className="brand-caption">{t.subtitle}</div>
          </div>
        </div>
        <div className="top-actions">
          <div
            className={`provider-health ${providerStatus.data?.configured ? "ready" : "offline"}`}
            title={providerStatus.data?.detail ?? "Checking Gemini status"}
          >
            <span />
            {providerStatus.isLoading
              ? "AI check…"
              : providerStatus.data?.configured
                ? `Gemini · ${providerStatus.data.model}`
                : "AI fallback"}
          </div>
          <div className="language-switcher" aria-label="Language">
            <Globe2 size={15} />
            {(["ur", "en", "pa"] as const).map(code => (
              <button
                key={code}
                className={language === code ? "active" : ""}
                onClick={() => setLanguage(code)}
              >
                {code === "ur" ? "اردو" : code === "pa" ? "پنجابی" : "EN"}
              </button>
            ))}
          </div>
          <Button
            variant="ghost"
            className="history-button"
            onClick={() => {
              if (!isAuthenticated) return startLogin();
              document
                .getElementById("case-history")
                ?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
          >
            <History size={16} />
            {t.history}
          </Button>
          <Button
            variant="outline"
            className="menu-button"
            onClick={() =>
              document
                .getElementById("workspace")
                ?.scrollIntoView({ behavior: "smooth", block: "start" })
            }
          >
            <Menu size={17} />
          </Button>
        </div>
      </header>
      <main className="main-wrap">
        <section className="hero-grid">
          <div className="hero-copy">
            <div className="eyebrow">
              <span className="eyebrow-dot" />
              {t.safe} · BEOE evidence navigator
            </div>
            <h1>{t.hero}</h1>
            <p>{t.intro}</p>
            <div className="hero-actions">
              <Button className="primary-button" onClick={reset}>
                {t.newCase}
                <ArrowRight size={16} />
              </Button>
              <Button
                variant="outline"
                className="demo-button"
                onClick={() => useDemo()}
              >
                <Sparkles size={16} />
                {t.tryDemo}
              </Button>
            </div>
            <div className="privacy-line">
              <LockKeyhole size={14} /> No passport, CNIC, PIN, or payment
              credentials ·{" "}
              {isAuthenticated && user
                ? `Signed in as ${user.name ?? "you"}`
                : "Private by design"}
            </div>
          </div>
          <div className="hero-visual">
            <div className="geometry geometry-one" />
            <div className="geometry geometry-two" />
            <div className="dotted-globe" aria-hidden="true">
              <span className="globe-latitude globe-latitude-one" />
              <span className="globe-latitude globe-latitude-two" />
              <span className="globe-longitude globe-longitude-one" />
              <span className="globe-longitude globe-longitude-two" />
            </div>
            <div className="hero-card">
              <div className="hero-card-top">
                <span className="mini-label">CASE PREVIEW</span>
                <span className="case-chip">03 fields need review</span>
              </div>
              <div className="fake-document">
                <div className="fake-doc-line long" />
                <div className="fake-doc-line" />
                <div className="fake-doc-line short" />
                <div className="fake-stamp">
                  BEOE
                  <br />
                  CHECK
                </div>
              </div>
              <div className="hero-status-row">
                <span className="status-dot pink" />
                <strong>CONFLICT</strong>
                <span>salary / fee</span>
                <ChevronLeft size={15} />
              </div>
              <div className="hero-status-row">
                <span className="status-dot blue" />
                <strong>MATCH</strong>
                <span>licence record</span>
                <ChevronLeft size={15} />
              </div>
            </div>
          </div>
        </section>
        <section className="workspace-card" id="workspace">
          <div className="stepper">
            {[
              [1, t.step1],
              [2, t.step2],
              [3, t.step3],
            ].map(([number, label]) => (
              <div
                key={number}
                className={`step-item ${step === Number(number) ? "current" : step > Number(number) ? "done" : ""}`}
              >
                <div className="step-number">
                  {step > Number(number) ? <Check size={14} /> : number}
                </div>
                <span>{label}</span>
              </div>
            ))}
          </div>
          {step === 1 && (
            <div className="step-content intake-grid">
              <div className="intake-main">
                <div className="section-heading">
                  <div>
                    <div className="section-kicker">01 · INTAKE</div>
                    <h2>{t.uploadTitle}</h2>
                    <p>{t.uploadHelp}</p>
                  </div>
                  <Fingerprint size={26} />
                </div>
                <label className="upload-zone">
                  {fileName ? (
                    <>
                      <FileImage size={22} />
                      <span>{fileName}</span>
                      <button
                        type="button"
                        className="remove-file"
                        onClick={e => {
                          e.preventDefault();
                          setFileName("");
                          setFileData(undefined);
                        }}
                      >
                        <X size={14} />
                      </button>
                    </>
                  ) : (
                    <>
                      <Upload size={22} />
                      <span>
                        {language === "en"
                          ? "Drop a file or browse"
                          : "فائل منتخب کریں"}
                      </span>
                      <small>max 5 MB</small>
                    </>
                  )}
                  <input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={handleFile}
                  />
                </label>
                <div className="redaction-note">
                  <input
                    type="checkbox"
                    checked={redactedConfirmed}
                    onChange={e => setRedactedConfirmed(e.target.checked)}
                  />
                  <span>
                    {language === "en"
                      ? "I removed passport, CNIC, payment, and login details from this upload."
                      : "میں نے اس فائل سے پاسپورٹ، CNIC، ادائیگی اور لاگ اِن کی تفصیلات ہٹا دی ہیں۔"}
                  </span>
                </div>
                <div className="or-divider">
                  <span>OR</span>
                </div>
                <div className="field-label">
                  <span>{t.typedTitle}</span>
                  <span className="optional">optional</span>
                </div>
                <Textarea
                  value={typedText}
                  onChange={e => setTypedText(e.target.value)}
                  placeholder={t.typedPlaceholder}
                  className="typed-area"
                />
                <div className="intake-footer">
                  <div className="voice-note">
                    <Mic2 size={15} />
                    <span>
                      {language === "en"
                        ? "Voice explanation available after the evidence check"
                        : "ثبوت چیک کے بعد نتیجہ آواز میں سنیں"}
                    </span>
                  </div>
                  <Button
                    className="primary-button"
                    onClick={handleExtract}
                    disabled={busy}
                  >
                    {busy ? (
                      <RefreshCw className="spin" size={15} />
                    ) : (
                      <Sparkles size={15} />
                    )}
                    {t.extract}
                  </Button>
                </div>
              </div>
              <aside className="guardrail-panel">
                <div className="guardrail-icon">
                  <LockKeyhole size={17} />
                </div>
                <h3>
                  {language === "en" ? "A safer way to check" : "محفوظ طریقہ"}
                </h3>
                <p>
                  {language === "en"
                    ? "We show evidence and uncertainty. We never decide for you."
                    : "ہم ثبوت اور غیر یقینی دکھاتے ہیں۔ فیصلہ آپ خود کرتے ہیں۔"}
                </p>
                <div className="guardrail-list">
                  <div>
                    <Check size={14} />
                    MATCH / CONFLICT / UNKNOWN
                  </div>
                  <div>
                    <Check size={14} />
                    Official source links
                  </div>
                  <div>
                    <Check size={14} />
                    No payment decisions
                  </div>
                  <div>
                    <Check size={14} />
                    Redact sensitive IDs
                  </div>
                </div>
                <Button
                  variant="link"
                  className="sample-link"
                  onClick={() => useDemo()}
                >
                  {language === "en"
                    ? "See a synthetic example"
                    : "فرضی مثال دیکھیں"}
                  <ArrowRight size={14} />
                </Button>
              </aside>
            </div>
          )}
          {step === 2 && (
            <div className="step-content">
              <div className="section-heading review-heading">
                <div>
                  <div className="section-kicker">02 · CONFIRM</div>
                  <h2>{t.reviewTitle}</h2>
                  <p>{t.reviewHelp}</p>
                </div>
                <Badge
                  variant="outline"
                  className={`provider-badge ${provider === "gemini" ? "is-live" : "is-fallback"}`}
                >
                  {provider === "gemini"
                    ? "GEMINI EXTRACTION"
                    : "FALLBACK / DEMO"}
                  {providerState
                    ? ` · ${providerState.replaceAll("_", " ")}`
                    : ""}
                </Badge>
              </div>
              <div className="review-banner">
                <AlertCircle size={16} />
                <span>
                  {extractionNote ||
                    (language === "en"
                      ? "AI can misread names, numbers, or languages. You must confirm each field."
                      : "AI نام، نمبرز یا زبان غلط پڑھ سکتا ہے۔ ہر فیلڈ کی تصدیق ضروری ہے۔")}
                </span>
              </div>
              <label className="confirm-check">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={e => setConfirmed(e.target.checked)}
                />
                <span>
                  {language === "en"
                    ? "I reviewed and corrected every field above."
                    : language === "pa"
                      ? "میں ہر فیلڈ ویکھ کے ٹھیک کر دِتی اے۔"
                      : "میں نے اوپر ہر فیلڈ کا جائزہ لے کر درست کر دیا ہے۔"}
                </span>
              </label>
              <div className="claims-grid">
                {fields.map(([key, english, urdu]) => (
                  <label key={key} className="claim-field">
                    <span>
                      {language === "en" ? english : urdu}
                      <small>{language === "en" ? urdu : english}</small>
                    </span>
                    <Input
                      value={claims[key]}
                      onChange={e => setField(key, e.target.value)}
                      placeholder="—"
                    />
                  </label>
                ))}
              </div>
              <div className="review-footer">
                <Button variant="ghost" onClick={() => setStep(1)}>
                  <ChevronLeft size={15} />
                  {language === "en" ? "Back" : "واپس"}
                </Button>
                <div className="review-actions">
                  <Button variant="outline" onClick={() => useDemo()}>
                    <Sparkles size={15} />
                    {language === "en" ? "Load demo" : "ڈیمو"}
                  </Button>
                  <Button
                    className="primary-button"
                    onClick={handleCheck}
                    disabled={busy || !hasClaims || !confirmed}
                  >
                    {busy ? (
                      <RefreshCw className="spin" size={15} />
                    ) : (
                      <ShieldCheck size={15} />
                    )}
                    {t.runCheck}
                  </Button>
                </div>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="step-content">
              <div className="section-heading evidence-heading">
                <div>
                  <div className="section-kicker">03 · EVIDENCE</div>
                  <h2>{t.evidenceTitle}</h2>
                  <p>
                    {language === "en"
                      ? "Source-aware evidence, transparent statuses, and official next steps."
                      : "ماخذ سے آگاہ ثبوت، صاف statuses، اور سرکاری اگلے اقدامات۔"}
                  </p>
                </div>
                <div className={`snapshot-pill ${retrieval?.fallbackUsed ? "fallback" : "live"}`}>
                  <span className="snapshot-dot" />
                  {retrieval?.fallbackUsed
                    ? `${t.snapshot} · fallback`
                    : "Live source record"}
                </div>
              </div>
              {retrieval && (
                <div className={`source-status ${retrieval.fallbackUsed ? "is-fallback" : "is-live"}`}>
                  <div>
                    <strong>{retrieval.fallbackUsed ? "Live source unavailable — dated fallback shown" : "Live official source record returned"}</strong>
                    <p>{retrieval.detail}</p>
                  </div>
                  <div className="source-status-meta">
                    <span>{retrieval.result.replaceAll("_", " ")}</span>
                    <span>{new Date(retrieval.retrievedAt).toLocaleString()}</span>
                  </div>
                </div>
              )}
              {actionCard && (
                <div className="action-card">
                  <div className="action-card-accent" />
                  <div>
                    <div className="action-title">{actionCard.headline}</div>
                    <p>{actionCard.summary}</p>
                    <p className="action-next">{actionCard.next}</p>
                    <div className="action-source">
                      <a
                        href={actionCard.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Link2 size={12} /> BEOE source
                      </a>
                      <span>{actionCard.sourceTitle}</span>
                      <span>Retrieved {actionCard.retrievedAt}</span>
                    </div>
                  </div>
                  <ShieldCheck className="action-shield" size={28} />
                </div>
              )}
              {actionCard && (
                <div className="ai-explanation-panel">
                  <div>
                    <div className="section-kicker">AI EXPLANATION</div>
                    <h3>
                      {language === "en"
                        ? "Understand the result"
                        : language === "pa"
                          ? "نتیجہ سمجھو"
                          : "نتیجہ سمجھیں"}
                    </h3>
                    {aiExplanation ? (
                      <p>{aiExplanation}</p>
                    ) : (
                      <p>
                        {language === "en"
                          ? "Generate an evidence-linked explanation in your selected language. Provider failures are shown instead of being hidden."
                          : "اپنی منتخب زبان میں ثبوت سے منسلک وضاحت بنائیں۔ AI کی ناکامی کو چھپایا نہیں جائے گا۔"}
                      </p>
                    )}
                    {explanationNote && <small className="explanation-note">{explanationNote}</small>}
                  </div>
                  <Button
                    variant="outline"
                    onClick={handleExplain}
                    disabled={busy}
                  >
                    {busy ? (
                      <RefreshCw className="spin" size={15} />
                    ) : (
                      <Sparkles size={15} />
                    )}
                    {aiExplanation
                      ? explanationProvider === "gemini"
                        ? "Refresh Gemini explanation"
                        : "Use fallback explanation"
                      : "Explain with Gemini"}
                  </Button>
                </div>
              )}
              {aiExplanation && (
                <div className="ai-explanation-copy">
                  <Badge variant="outline">
                    {explanationProvider === "gemini" ? "GEMINI" : "FALLBACK"}{explanationState ? ` · ${explanationState.replaceAll("_", " ")}` : ""}
                  </Badge>
                  <p>{aiExplanation}</p>
                </div>
              )}
              <div className="evidence-table">
                {evidence.map(row => (
                  <div className="evidence-row" key={row.field}>
                    <div className="evidence-label">
                      <strong>{row.label}</strong>
                      <span>{row.claim}</span>
                    </div>
                    <Badge className={statusClass(row.status)}>
                      {statusLabel(row.status)}
                    </Badge>
                    <div className="evidence-explanation">
                      {row.explanation}
                      <small>{row.sourceTitle} · {row.retrievedAt}</small>
                    </div>
                    <a href={row.sourceUrl} target="_blank" rel="noreferrer">
                      <Link2 size={13} />
                      {t.source} <span>↗</span>
                    </a>
                  </div>
                ))}
              </div>
              <div className="evidence-footer">
                <Button variant="ghost" onClick={() => setStep(2)}>
                  <ChevronLeft size={15} />
                  {language === "en" ? "Edit fields" : "فیلڈز درست کریں"}
                </Button>
                <div className="review-actions">
                  <Button
                    variant="outline"
                    onClick={speakActionCard}
                    disabled={voiceSpeaking || !actionCard}
                  >
                    <Mic2 size={15} />
                    {voiceSpeaking
                      ? language === "en"
                        ? "Speaking…"
                        : "سنایا جا رہا ہے…"
                      : language === "en"
                        ? "Explain aloud"
                        : "آواز میں سمجھائیں"}
                  </Button>
                  <Button variant="outline" onClick={reset}>
                    {t.reset}
                  </Button>
                  <Button className="primary-button" onClick={handleSave}>
                    {isAuthenticated ? (
                      <>
                        <History size={15} />
                        {t.save}
                      </>
                    ) : (
                      <>
                        <LockKeyhole size={15} />
                        {t.signIn}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </section>
        <section className="trust-strip">
          <div>
            <span className="strip-number">01</span>
            <strong>
              {language === "en"
                ? "Evidence, not verdicts"
                : "فیصلہ نہیں، ثبوت"}
            </strong>
            <span>
              {language === "en"
                ? "Neutral statuses keep uncertainty visible."
                : "غیر جانبدار statuses غیر یقینی دکھاتے ہیں۔"}
            </span>
          </div>
          <div>
            <span className="strip-number">02</span>
            <strong>
              {language === "en"
                ? "Built for real language"
                : "اصل زبان کے لیے"}
            </strong>
            <span>
              {language === "en"
                ? "Urdu-first, with English and Punjabi copy."
                : "اردو اول، انگریزی اور پنجابی کے ساتھ۔"}
            </span>
          </div>
          <div>
            <span className="strip-number">03</span>
            <strong>
              {language === "en" ? "You stay in control" : "فیصلہ آپ کا"}
            </strong>
            <span>
              {language === "en"
                ? "No automatic complaints or payments."
                : "کوئی خودکار شکایت یا ادائیگی نہیں۔"}
            </span>
          </div>
        </section>
        {isAuthenticated && (
          <section className="history-section" id="case-history">
            <div className="section-kicker">PRIVATE HISTORY</div>
            <h2>
              {language === "en" ? "Your saved cases" : "آپ کے محفوظ کیسز"}
            </h2>
            {cases.data?.length ? (
              <div className="history-grid">
                {cases.data.slice(0, 3).map(item => (
                  <Card
                    key={item.id}
                    className={`history-card ${selectedCaseId === item.id ? "selected" : ""}`}
                  >
                    <CardHeader>
                      <CardTitle>{item.title}</CardTitle>
                      <CardDescription>
                        {new Date(item.createdAt).toLocaleString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="history-card-actions">
                        <Badge className="status-match">CHECKED</Badge>
                        <Button
                          variant="link"
                          onClick={() => setSelectedCaseId(item.id)}
                        >
                          {language === "en" ? "View details" : "تفصیل"}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={async () => {
                            await deleteCase.mutateAsync({ id: item.id });
                            await cases.refetch();
                            if (selectedCaseId === item.id)
                              setSelectedCaseId(null);
                          }}
                        >
                          {language === "en" ? "Delete" : "حذف"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <p className="muted-copy">
                {language === "en"
                  ? "Your confirmed cases will appear here."
                  : "آپ کے تصدیق شدہ کیسز یہاں نظر آئیں گے۔"}
              </p>
            )}
            {selectedCase.data && (
              <div className="case-detail">
                <div>
                  <strong>{String(selectedCase.data.title)}</strong>
                  <span>
                    {new Date(
                      String(selectedCase.data.createdAt)
                    ).toLocaleString()}
                  </span>
                </div>
                <p>
                  {language === "en"
                    ? "Saved structured claims and evidence remain tied to your account."
                    : "محفوظ دعوے اور ثبوت آپ کے اکاؤنٹ سے منسلک ہیں۔"}
                </p>
                <div className="saved-claims">
                  {Object.entries(
                    selectedCase.data.extractedClaims as Record<string, string>
                  ).map(([key, value]) => (
                    <div key={key}>
                      <span>{key}</span>
                      <strong>{String(value || "—")}</strong>
                    </div>
                  ))}
                </div>
                {selectedCase.data.retrievals?.[0] && (
                  <div className="saved-retrieval">
                    <div>
                      <span>Evidence source status</span>
                      <strong>
                        {String(selectedCase.data.retrievals[0].sourceMode).replaceAll("_", " ")} · {String(selectedCase.data.retrievals[0].result).replaceAll("_", " ")}
                      </strong>
                    </div>
                    <p>{String(selectedCase.data.retrievals[0].detail)}</p>
                    <a href={String(selectedCase.data.retrievals[0].sourceUrl)} target="_blank" rel="noreferrer">
                      {String(selectedCase.data.retrievals[0].sourceTitle)} · {new Date(String(selectedCase.data.retrievals[0].retrievedAt)).toLocaleString()} ↗
                    </a>
                  </div>
                )}
                <div className="saved-evidence">
                  {selectedCase.data.evidence.map((row: any) => (
                    <div key={row.id}>
                      <div>
                        <strong>{String(row.field)}</strong>
                        <Badge
                          className={statusClass(
                            row.status as Evidence["status"]
                          )}
                        >
                          {String(row.status)}
                        </Badge>
                      </div>
                      <p>{String(row.claim)}</p>
                      <span>{String(row.explanation)}</span>
                      <a
                        href={String(row.sourceUrl ?? "https://beoe.gov.pk/")}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Source ·{" "}
                        {String(row.retrievedAt ?? "")
                          ? new Date(
                              String(row.retrievedAt)
                            ).toLocaleDateString()
                          : "dated snapshot"}{" "}
                        ↗
                      </a>
                    </div>
                  ))}
                </div>
                {Boolean(selectedCase.data.actionCard) && (
                  <div className="saved-action">
                    <strong>
                      {String(
                        (selectedCase.data.actionCard as { headline?: string })
                          .headline ?? "Saved action card"
                      )}
                    </strong>
                    <p>
                      {String(
                        (selectedCase.data.actionCard as { summary?: string })
                          .summary ?? ""
                      )}
                    </p>
                    <a
                      href={String(
                        (selectedCase.data.actionCard as { sourceUrl?: string })
                          .sourceUrl ?? "https://beoe.gov.pk/"
                      )}
                      target="_blank"
                      rel="noreferrer"
                    >
                      BEOE source ·{" "}
                      {String(
                        (
                          selectedCase.data.actionCard as {
                            retrievedAt?: string;
                          }
                        ).retrievedAt ?? "dated snapshot"
                      )}{" "}
                      ↗
                    </a>
                  </div>
                )}
                {selectedCase.data.documents.length > 0 && (
                  <div className="saved-documents">
                    {selectedCase.data.documents.map(doc => (
                      <div key={doc.id}>
                        <a
                          href={String(doc.storageUrl)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          <FileImage size={13} />
                          {String(doc.fileName)}
                        </a>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={async () => {
                            await deleteDocument.mutateAsync({ id: doc.id });
                            await selectedCase.refetch();
                          }}
                        >
                          {language === "en" ? "Remove" : "ہٹائیں"}
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </section>
        )}
      </main>
      <footer className="footer">
        <span>ClearPath / 2026</span>
        <span>
          For awareness and safer verification ·{" "}
          <a href="https://beoe.gov.pk/" target="_blank" rel="noreferrer">
            Official BEOE
          </a>
        </span>
      </footer>
    </div>
  );
}
