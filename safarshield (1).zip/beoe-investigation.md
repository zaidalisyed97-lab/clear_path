# BEOE public workflow investigation

Date: 2026-09-05

## Direct access observations

Normal browser navigation to `https://beoe.gov.pk/` returned a JSON response saying `{"message":"Please contact the site owner for access."}`. Normal navigation to `https://beoe.gov.pk/list-of-oeps?show=active` returned the same response. No visible form, public table, API response, or lookup controls were available in the browser session. No Cloudflare bypass, CAPTCHA bypass, stealth automation, or private session was attempted.

## Public discovery observations

Public search indexing exposes official BEOE pages including the List of Overseas Employment Promoters, Complaints, Foreign Jobs, and individual foreign-job permission pages. Search results indicate that the OEP list includes licence status categories such as valid, invalid, expired, cancelled, surrendered, and suspended. Search indexing is not a live verification source and must not be treated as current record data.

## Preliminary conclusion

The BEOE portal is publicly discoverable but is not directly accessible to this normal automated browser session because the site owner’s bot-protection layer returned an access-denied response. ClearPath should not attempt to bypass this control. A production live-query integration requires either an approved BEOE API/data export, permission for a supported integration, or a human-assisted verification step. Until one of those exists, ClearPath should use a dated curated fallback and show a clear `LIVE_SOURCE_UNAVAILABLE` state rather than claiming a live match.
