# ClearPath

## Evidence before payment

ClearPath is an Urdu-first, responsive web application that helps Pakistani job seekers and families organize overseas-employment offers before they pay money or share sensitive documents. It accepts typed details, screenshots, and supported document images, extracts structured claims with server-side Google Gemini, requires the user to review and correct those claims, and compares them with a dated, curated BEOE demonstration snapshot.

ClearPath is deliberately **not** a scam detector, legal adviser, government verifier, or payment-decision engine. It does not declare an offer genuine, fake, or fraudulent. Instead, it makes uncertainty visible through four neutral evidence states: `MATCH`, `CONFLICT`, `NOT FOUND`, and `NOT CHECKED`.

> **ClearPath turns a messy overseas-job offer into a transparent evidence checklist before money or documents leave the family.**

## The problem

A prospective migrant worker may receive an overseas-job offer through WhatsApp, a screenshot, a PDF, a phone call, or a voice note. The important claims are usually scattered across informal messages: recruiter identity, Overseas Employment Promoter licence, job title, destination country, salary, requested fee, deadline, and pressure to pay immediately. The person must then decide which official source to consult and how to interpret unfamiliar employment and government language.

The problem is not simply that information is absent. It is that **information is fragmented, multilingual, time-sensitive, and difficult to reconcile under financial pressure**. A normal search engine does not tell a user which fields to compare, does not preserve the evidence trail, and does not explain the difference between a missing record and a conflicting record.

The Government of Pakistan’s Bureau of Emigration & Overseas Employment publishes public workflows for foreign jobs, licensed Overseas Employment Promoters, complaints, illegal-recruitment guidance, and emigrant fee information.[1] The existence of these official workflows demonstrates that overseas-employment verification is a real institutional process rather than a problem that can be solved responsibly by a generic chatbot.

## Economic relevance

Overseas employment is connected to household income and Pakistan’s wider remittance economy. The State Bank of Pakistan maintains a regularly updated economic-data section containing workers’ remittance series.[2] Those values change over time, so ClearPath does not hard-code a volatile national remittance total into its product logic. The economic argument for the prototype is more specific: when a household is deciding whether to pay a recruitment fee or surrender documents, a small improvement in clarity can protect a financially meaningful decision.

ClearPath does **not** claim that remittance totals prove recruitment fraud or that every recruiter is unsafe. Economic scale establishes why the decision matters; the product’s evidence workflow addresses the narrower problem of helping a user inspect an offer before acting.

## The proposed solution

ClearPath uses a human-in-the-loop, evidence-first workflow:

| Stage | Product behavior |
|---|---|
| Intake | The user types offer details or uploads a synthetic/redacted image or document. |
| Privacy gate | The user is reminded not to submit passports, CNICs, PINs, passwords, or payment credentials. Uploads require redaction confirmation. |
| Extraction | Gemini extracts only explicitly stated fields and leaves unknown values blank. The server keeps the API key private. |
| Confirmation | The user reviews and corrects every extracted field before any evidence check runs. |
| Evidence retrieval | ClearPath first attempts a normal, permitted BEOE public-source request using the confirmed recruiter or licence. It records the source URL, retrieval time, and availability result. |
| Evidence check | A deterministic engine compares confirmed fields with a returned approved record when available; otherwise it uses a clearly labelled dated, curated BEOE fallback snapshot. |
| Explanation | ClearPath provides source-linked evidence, retrieval dates, uncertainty, and safe next steps. Gemini can produce a constrained Urdu, Punjabi, or English explanation of the structured result. |
| Voice access | The user can play the result aloud through the browser’s speech-synthesis capability. This is an accessibility aid, not a clinical or legal voice authority. |
| History | Signed-in users can save structured cases, view evidence details, manage uploaded document references, and delete saved cases or documents. |

## Why AI is used

AI is used where it adds practical value, not where a deterministic rule is safer. Gemini handles document and language complexity: it can extract fields from a supported image, understand mixed-language text, and explain a structured report in the selected language. It is not permitted to decide whether an offer is authentic.

The evidence status is deterministic. The application compares normalized confirmed fields with the dated snapshot and records the source URL, source title, and retrieval date. This separation prevents a language model from converting a plausible guess into an official-sounding verdict.

## Technical overview

```text
User browser
   |
   | typed details or redacted image
   v
React 19 + Tailwind 4 frontend
   |
   | typed tRPC contract
   v
Express 4 + tRPC 11 backend
   |
   +--> Gemini 3.6 Flash REST API (server-side key only)
   |       structured extraction and explanation
   |
   +--> deterministic ClearPath service
   |       normalization, privacy warnings, snapshot matching
   |
   +--> BEOE source adapter
   |       normal permitted lookup attempt, source URL, retrieval time, availability state
   |       ↓ when no approved machine-readable response is available
   +--> dated BEOE fallback snapshot
   |       MATCH / CONFLICT / NOT FOUND / NOT CHECKED; never represented as live data
   |
   +--> MySQL/TiDB through Drizzle ORM
   |       signed-in cases, evidence rows, document references
   |
   +--> S3-compatible storage
           uploaded document bytes outside the database
```

### Main technology choices

| Layer | Technology | Role |
|---|---|---|
| Frontend | React 19, Vite, Tailwind CSS 4, shadcn/ui primitives | Responsive Urdu-first intake and evidence interface |
| Backend | Node.js, Express 4, tRPC 11 | Typed server procedures and secure provider calls |
| Authentication | Manus OAuth template integration | Signed-in case history and ownership checks |
| Database | Drizzle ORM with MySQL/TiDB | Cases, claims, evidence rows, and document metadata |
| File storage | S3-compatible storage helper | Uploaded document bytes stored outside database columns |
| AI | Google Gemini 3.6 Flash REST API | Server-side structured extraction and constrained neutral explanation |
| Evidence source | Cloudflare-safe BEOE source adapter | Makes a normal permitted request; records success, source unavailability, or bot-protection block without bypassing controls |
| Fallback | Local deterministic parser, dated snapshot, and synthetic demo cases | Full demonstration without Gemini or live government availability |
| Accessibility | Browser SpeechSynthesis API | Optional aloud playback of the evidence action card |

## Privacy and safety boundaries

ClearPath follows a conservative prototype boundary. It does not request passport numbers, CNIC numbers, bank credentials, PINs, passwords, or one-time passwords. The server checks typed text for sensitive patterns and blocks sensitive uploads from being sent to Gemini. The user must confirm that an uploaded file has been redacted before extraction.

A `NOT FOUND` result means that a claim was not found in the limited dated snapshot. It does not mean that the claim is fraudulent. A `CONFLICT` result means that the supplied claim did not align with the specific record checked. It does not identify a person as a criminal. Users are instructed to confirm current status through official BEOE resources.

All demonstration records are synthetic or curated for prototype evaluation. For each confirmed case, ClearPath attempts a normal public BEOE lookup only where the portal permits it. As observed during prototype development, the public BEOE portal may return a bot-protection/access-denied response instead of a usable machine-readable record. ClearPath does not bypass Cloudflare, CAPTCHA, access controls, or website terms. When a live response is blocked or unavailable, the app shows the reason, source link, and retrieval time and uses a dated fallback snapshot that is visibly labelled as fallback data.

## Synthetic demonstration cases

The app includes synthetic cases that demonstrate different evidence outcomes, including a pressured Saudi driver offer and a mixed-evidence Qatar electrician offer. The intended demonstration shows that ClearPath can produce a match, a conflict, and an unknown without collapsing all uncertainty into a sensational fraud score.

A recommended three-minute demonstration is:

1. Choose **Try a demo case**.
2. Review the extracted fields and deliberately correct one field.
3. Confirm that every field was reviewed.
4. Run the evidence check.
5. Show one `MATCH`, one `CONFLICT`, and one `NOT FOUND` or `NOT CHECKED` result.
6. Click **Explain with Gemini** and show the neutral language explanation.
7. Click **Explain aloud** to demonstrate accessibility.
8. Open the official BEOE source link and emphasize that the final decision remains with the user and official channels.

## Local installation

### Requirements

Install Node.js 22 or a compatible current Node.js release, pnpm 10, and access to a MySQL-compatible database if you want persistent signed-in case history. A Gemini key is optional for local fallback demonstrations and required only for live Gemini extraction and explanation.

### Install dependencies

```bash
pnpm install
```

### Configure environment variables

Create a local environment file only on your own machine. Do not commit it to GitHub and do not place secrets in browser code.

```bash
DATABASE_URL="your-mysql-or-tidb-connection-string"
JWT_SECRET="a-long-random-server-secret"
GEMINI_API_KEY="your-google-gemini-api-key"
GEMINI_MODEL="gemini-3.6-flash"
BEOE_LOOKUP_URL="https://your-approved-beoe-lookup-endpoint.example"
```

`BEOE_LOOKUP_URL` is optional and must point to an approved, machine-readable BEOE data endpoint that returns the structured fields ClearPath expects. Do not configure the public portal’s protected HTML page as an API and do not bypass Cloudflare, CAPTCHA, access controls, or terms. If this variable is absent or the endpoint is unavailable, ClearPath records the live-source limitation and uses the clearly labelled dated fallback.

The hosted project may also require the platform-provided OAuth, storage, and application variables. In the managed environment, configure secrets through the project’s secret manager rather than committing a `.env` file.

### Database setup

The repository contains the Drizzle schema and generated migration for the ClearPath case, evidence, and document-reference tables. For a new local database, review the migration before applying it:

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

Do not run destructive database commands against a production database. The hosted project uses the managed database migration workflow.

### Start development

```bash
pnpm dev
```

Open the local URL printed by the development server. If `GEMINI_API_KEY` is absent, use **Try a demo case** or type a synthetic offer; the fallback parser and deterministic evidence engine remain available.

## Verification commands

```bash
pnpm check
pnpm test
pnpm build
```

The test suite covers neutral evidence statuses, structured snapshot mapping, privacy warnings, synthetic fallback behavior, protected upload/deletion procedures, the Gemini credential check, and ClearPath branding configuration.

## Final portal submission

The organizers have stated that **everything is submitted through the online portal**. The current Discord announcement extends submissions until **7 September 2026 at 23:59 PKT**. The team lead’s registered email is used to access the portal account; the password-setting email is sent from `no-reply@aihackathon.cognix-pk.com`. Confirm the final deadline and any field-specific requirements in the latest organizer email before submitting.

The portal asks teams to share a public GitHub repository and present the problem, affected users, solution, impact, technology, and what has actually been built. Submit the GitHub URL as the primary artifact. Keep this README at the repository root so judges can understand and run the project. Include the hosted demo URL only if it is available and working at the time of submission; the repository’s synthetic fallback is the reliable evaluator path.

The managed preview may be temporarily unavailable because the current hosting project has reached its regional service quota. This is a hosting-capacity limitation, not a requirement for the application itself. For judging, use the public GitHub repository and run the synthetic fallback locally; provide a hosted URL only after confirming that it opens successfully.

ClearPath is a full-stack Node application rather than a static HTML file. Evaluators need Node.js, pnpm, a MySQL-compatible database for persistence, and environment variables for optional Gemini and hosted authentication. They can still run the synthetic demo without Gemini or live government-site access. `ENV_TEMPLATE.md` contains placeholder configuration guidance.

Before making the repository public, inspect the entire commit history—not only the latest files. Never include `GEMINI_API_KEY`, `DATABASE_URL`, `JWT_SECRET`, OAuth secrets, storage credentials, `.env` files, or tokens in GitHub or a ZIP. If any credential was ever committed, revoke or rotate it before sharing the repository. The existing `.gitignore` excludes environment files, and the repository contains no detected key assignments in tracked source during the final audit.

## Limitations and next steps

The prototype uses a Cloudflare-safe BEOE source adapter and a dated curated fallback rather than a continuously synchronized official government database. It does not prove identity, validate concealed employment terms, certify an offer, file complaints automatically, or make a payment decision. A production release would require an official machine-readable data-access agreement, source freshness monitoring, security review, human escalation, Urdu and Punjabi language testing, independent usability research, and legal review of its operating model.

The next technical step is a governed data-refresh process that preserves source versions and retrieval dates. The next product step is testing the workflow with job seekers, families, and qualified migrant-resource professionals without collecting real identity documents.

## References

[1]: https://beoe.gov.pk/ "Bureau of Emigration & Overseas Employment, Government of Pakistan"
[2]: https://www.sbp.org.pk/economic-data "State Bank of Pakistan, Economic Data"
[3]: https://www.alibabacloud.com/help/en/model-studio/vision-model/ "Alibaba Cloud Model Studio: Visual understanding"
[4]: https://www.alibabacloud.com/help/en/model-studio/models "Alibaba Cloud Model Studio: Recommended models"
