# ClearPath — submission presentation brief

## One-line pitch

**ClearPath helps Pakistani job seekers and families inspect overseas-job offers before paying or sharing sensitive documents by turning screenshots and voice notes into a source-linked, multilingual evidence checklist.**

## The problem

Overseas-job offers often arrive through WhatsApp screenshots, PDFs, informal messages, and voice notes. Recruiter identity, licence details, salary, fees, deadlines, and pressure language are fragmented across formats and languages. A person under financial pressure must decide what to trust and which official source to consult.

This matters economically because overseas employment is connected to household income and Pakistan’s remittance economy. The State Bank of Pakistan maintains regularly updated workers’ remittance data, while the Bureau of Emigration & Overseas Employment provides official foreign-job, Overseas Employment Promoter, complaints, and guidance workflows. ClearPath addresses the narrow decision point before payment: making the available evidence understandable and traceable.

## The solution

ClearPath accepts typed offer details or a redacted document image, uses server-side Gemini to extract structured claims, and requires the user to confirm or correct the fields. It then makes a normal, permitted lookup attempt against the relevant public BEOE workflow and records the source URL, retrieval time, and availability result. Where no approved machine-readable record is available—for example, when the portal’s bot protection blocks automated access—ClearPath makes the limitation visible and falls back to a dated curated demonstration snapshot. Each field receives one of four neutral statuses: `MATCH`, `CONFLICT`, `NOT FOUND`, or `NOT CHECKED`.

The result is an Urdu, English, or Punjabi action card with the evidence considered, the uncertainty that remains, source links, retrieval dates, and safe next steps. ClearPath never declares an offer genuine or fraudulent and never makes payment or complaint decisions automatically.

## What is built

The submitted prototype includes a responsive Urdu-first web interface, synthetic demo cases, server-side Gemini 3.6 Flash extraction and explanation, visible provider/fallback state, deterministic evidence comparison, a Cloudflare-safe BEOE source adapter, user confirmation, sensitive-data warnings, browser voice playback, signed-in case history, document references outside the database, ownership checks, deletion support, source provenance, and a warm brown visual identity.

## Technical overview

The application uses React 19, Vite, Tailwind CSS, shadcn/ui primitives, Node.js, Express, tRPC, Drizzle ORM, MySQL/TiDB, S3-compatible storage, Manus OAuth, and the Google Gemini API. Gemini is used for document/language assistance; deterministic application code controls evidence statuses. The API key remains server-side. The BEOE adapter does not bypass Cloudflare, CAPTCHA, or access controls: it records an explicit blocked/unavailable state and uses the dated fallback only when necessary.

## Responsible AI boundary

ClearPath is an evidence navigator, not a government verifier, lawyer, or fraud-detection guarantee. `NOT FOUND` means the claim was not found in the limited snapshot; it is not proof of wrongdoing. Users are instructed to confirm current information through official BEOE channels. The prototype does not request passport, CNIC, PIN, password, or payment credentials.

## Suggested three-minute presentation

Begin with a synthetic WhatsApp offer and an Urdu voice note demanding urgent payment. Upload it and show Gemini extracting recruiter, licence, country, salary, fee, and deadline fields. Correct one field to demonstrate that the human remains in control. Run the evidence check and show the visible BEOE source status: either a live record with a retrieval time or a clearly labelled live-source-unavailable fallback without any bot-protection bypass. Then show one match, one conflict, and one unknown. Open the action card, show the source URL and retrieval date, use the Gemini explanation, and play the result aloud. Close by explaining that ClearPath does not replace official verification; it makes the first five minutes before payment clearer and safer.

## Submission note

The organizers have stated that submissions are made through the online portal and that the team lead’s registered email receives the access and password-setting message from `no-reply@aihackathon.cognix-pk.com`. The current Discord announcement extends the deadline to **7 September 2026 at 23:59 PKT**. Confirm the final deadline and required portal fields in the latest organizer email before submitting.

Share the public GitHub repository URL through the portal. Before sharing it, inspect the full commit history and confirm that no `.env` file, Gemini key, database URL, JWT secret, OAuth secret, token, or password exists anywhere in the repository history. The project’s `.gitignore` excludes environment files, `ENV_TEMPLATE.md` contains placeholders only, and synthetic cases provide the evaluator path without private credentials. If any real credential was ever committed, revoke or rotate it before making the repository public.

## References

[1]: https://beoe.gov.pk/ "Bureau of Emigration & Overseas Employment, Government of Pakistan"
[2]: https://www.sbp.org.pk/economic-data "State Bank of Pakistan, Economic Data"
[3]: https://www.alibabacloud.com/help/en/model-studio/vision-model/ "Alibaba Cloud Model Studio: Visual understanding"
[4]: https://www.alibabacloud.com/help/en/model-studio/models "Alibaba Cloud Model Studio: Recommended models"
