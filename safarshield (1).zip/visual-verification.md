# Visual verification

The warm brown and light-brown theme renders consistently on desktop and mobile. The dotted-line globe is visible as a subtle decorative hero motif behind the case preview without obscuring the Urdu headline, controls, or evidence card. Brown primary controls maintain clear contrast against the pale warm background, and the mobile layout preserves readable text, spacing, and the hero composition.

## Lower text outline update

Desktop review shows the three lower trust statements now sit in distinct outlined cards, with a larger outlined private-history panel and outlined footer. Mobile review shows the cards stack vertically without horizontal overflow, while the rounded outlines keep the lower copy visually grouped and readable.
