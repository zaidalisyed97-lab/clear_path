CREATE TABLE `source_retrievals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caseId` int NOT NULL,
	`sourceMode` enum('live','fallback','live_unavailable_fallback','demo') NOT NULL,
	`result` enum('success','not_found','blocked','unavailable','skipped') NOT NULL,
	`queryValue` varchar(180),
	`sourceUrl` text NOT NULL,
	`sourceTitle` text NOT NULL,
	`responseStatus` int,
	`detail` text,
	`retrievedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `source_retrievals_id` PRIMARY KEY(`id`)
);
