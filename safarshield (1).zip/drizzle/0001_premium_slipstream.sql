CREATE TABLE `case_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caseId` int NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`storageKey` text NOT NULL,
	`storageUrl` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `case_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `evidence_checks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caseId` int NOT NULL,
	`field` varchar(80) NOT NULL,
	`claim` text NOT NULL,
	`status` enum('MATCH','CONFLICT','NOT_FOUND','NOT_CHECKED') NOT NULL,
	`explanation` text NOT NULL,
	`sourceUrl` text,
	`sourceTitle` text,
	`retrievedAt` timestamp,
	CONSTRAINT `evidence_checks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `verification_cases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`language` enum('ur','en','pa') NOT NULL DEFAULT 'ur',
	`status` enum('draft','reviewed','checked') NOT NULL DEFAULT 'draft',
	`sourceMode` enum('typed','upload','demo') NOT NULL DEFAULT 'typed',
	`extractedClaims` json NOT NULL,
	`actionCard` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `verification_cases_id` PRIMARY KEY(`id`)
);
