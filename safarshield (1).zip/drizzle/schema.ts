import {
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const verificationCases = mysqlTable("verification_cases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  language: mysqlEnum("language", ["ur", "en", "pa"]).default("ur").notNull(),
  status: mysqlEnum("status", ["draft", "reviewed", "checked"])
    .default("draft")
    .notNull(),
  sourceMode: mysqlEnum("sourceMode", ["typed", "upload", "demo"])
    .default("typed")
    .notNull(),
  extractedClaims: json("extractedClaims").notNull(),
  actionCard: json("actionCard"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const evidenceChecks = mysqlTable("evidence_checks", {
  id: int("id").autoincrement().primaryKey(),
  caseId: int("caseId").notNull(),
  field: varchar("field", { length: 80 }).notNull(),
  claim: text("claim").notNull(),
  status: mysqlEnum("status", [
    "MATCH",
    "CONFLICT",
    "NOT_FOUND",
    "NOT_CHECKED",
  ]).notNull(),
  explanation: text("explanation").notNull(),
  sourceUrl: text("sourceUrl"),
  sourceTitle: text("sourceTitle"),
  retrievedAt: timestamp("retrievedAt"),
});

export const sourceRetrievals = mysqlTable("source_retrievals", {
  id: int("id").autoincrement().primaryKey(),
  caseId: int("caseId").notNull(),
  sourceMode: mysqlEnum("sourceMode", [
    "live",
    "fallback",
    "live_unavailable_fallback",
    "demo",
  ]).notNull(),
  result: mysqlEnum("result", [
    "success",
    "not_found",
    "blocked",
    "unavailable",
    "skipped",
  ]).notNull(),
  queryValue: varchar("queryValue", { length: 180 }),
  sourceUrl: text("sourceUrl").notNull(),
  sourceTitle: text("sourceTitle").notNull(),
  responseStatus: int("responseStatus"),
  detail: text("detail"),
  retrievedAt: timestamp("retrievedAt").defaultNow().notNull(),
});

export const caseDocuments = mysqlTable("case_documents", {
  id: int("id").autoincrement().primaryKey(),
  caseId: int("caseId").notNull(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  storageKey: text("storageKey").notNull(),
  storageUrl: text("storageUrl").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VerificationCase = typeof verificationCases.$inferSelect;
export type EvidenceCheck = typeof evidenceChecks.$inferSelect;
export type SourceRetrieval = typeof sourceRetrievals.$inferSelect;
export type CaseDocument = typeof caseDocuments.$inferSelect;
