# ClearPath environment template

Copy the following placeholder values into a local `.env.local` file when running the repository on your own machine. Replace placeholders only on the local machine or in a private hosting provider’s environment-variable settings. Never commit `.env`, `.env.local`, `.env.*`, or real credentials.

```bash
DATABASE_URL="mysql://user:password@host:3306/clearpath"
JWT_SECRET="replace-with-a-long-random-server-secret"
GEMINI_API_KEY="replace-with-your-server-side-gemini-key"
GEMINI_MODEL="gemini-3.6-flash"
BEOE_LOOKUP_URL="https://your-approved-beoe-lookup-endpoint.example"
OAUTH_SERVER_URL="https://api.manus.im"
VITE_OAUTH_PORTAL_URL="https://oauth.manus.im"
VITE_APP_ID="replace-with-oauth-app-id"
VITE_APP_TITLE="ClearPath"
```

`GEMINI_API_KEY`, `DATABASE_URL`, `JWT_SECRET`, and `BEOE_LOOKUP_URL` are server-side values. Do not prefix them with `VITE_`, because Vite-prefixed values can be exposed to browser code. `BEOE_LOOKUP_URL` is optional and must be an approved machine-readable source; never configure a protected portal page as an API or attempt to bypass Cloudflare. If Gemini or an approved BEOE source is not configured, use the clearly labelled synthetic fallback demo.
