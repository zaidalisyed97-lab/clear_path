# ClearPath — Full Project Specification

**Document version:** 1.0  
**Project name:** ClearPath  
**Product type:** Urdu-first full-stack web application  
**Primary purpose:** Help prospective overseas workers and their families organize job-offer claims into a transparent evidence checklist before they pay money or share sensitive documents.  
**Current implementation boundary:** Hackathon prototype with controlled Gemini extraction, deterministic evidence logic, an attempted public BEOE-source adapter, and a clearly labelled dated fallback.

> **Core product principle:** ClearPath does not decide whether an overseas job is genuine, fake, safe, unsafe, or fraudulent. It makes the offer’s claims, evidence, conflicts, source availability, and unknowns visible so the user can take safer next official steps.

---

## 1. Executive summary

ClearPath is designed for a common high-pressure situation: a person receives an overseas-job offer through a WhatsApp message, screenshot, PDF, agent, or phone call and must quickly understand the recruiter, licence, job, destination, salary, fee, deadline, and urgency claims. Rather than producing a vague chatbot answer, ClearPath converts the offer into structured fields, requires human confirmation of those fields, and then applies deterministic comparison rules to available evidence.

The prototype is deliberately structured so that **language AI and evidence decisions are separate**. Google Gemini reads and extracts text from a typed offer, supported image, or redacted PDF, and can explain the resulting evidence in the selected language. ClearPath’s own backend rules assign evidence states. This makes the decision process testable, auditable, and easier to defend than a model-generated verdict.

| Capability | Current behavior |
|---|---|
| Offer intake | Typed text, screenshots, supported images, and redacted PDF files up to the UI limit. |
| Languages | Urdu-first interface, with English and Punjabi copy. |
| Extraction | Gemini structured extraction when configured; local parser fallback when unavailable. |
| Human review | Users must correct or confirm the extracted claims before evidence checking. |
| Evidence output | `MATCH`, `CONFLICT`, `NOT FOUND`, and `NOT CHECKED` per claim. |
| BEOE data behavior | Normal public lookup attempt; no bypass of Cloudflare or access controls; dated fallback when no permitted machine-readable record is available. |
| Explanation | Constrained Gemini explanation or a local safety explanation when Gemini is unavailable. |
| Accessibility | Browser text-to-speech for the action-card result. |
| Private history | Signed-in users can save, inspect, and delete their cases and document references. |

---

## 2. Problem statement and intended users

### 2.1 Problem

Overseas employment decisions can involve high financial and personal stakes. Offers often arrive as unstructured content, with important information scattered across a message or document. A user may not know what to verify, which official channel to use, or how to interpret a missing or conflicting record.

Pakistan’s Bureau of Emigration & Overseas Employment (BEOE) publishes public information about overseas employment, licensed Overseas Employment Promoters (OEPs), foreign jobs, complaints, illegal-recruitment guidance, and emigrant fees.[1] ClearPath’s product premise is that official verification is a multi-step information task—not something that a general-purpose chatbot should falsely certify.

Pakistan’s remittance economy makes overseas employment a material household decision context. The State Bank of Pakistan maintains workers’ remittance series through its economic-data resources.[2] ClearPath does not claim that remittance totals prove fraud. Its narrower claim is that improving clarity before a fee payment or document handover can reduce avoidable uncertainty.

### 2.2 Target users

| User | Need | ClearPath support |
|---|---|---|
| Prospective overseas worker | Understand an offer before paying a fee or providing personal information. | Urdu-first intake, structured review, neutral evidence states, official links. |
| Family member | Help evaluate a relative’s offer from a screenshot, PDF, or message. | Clear explanation, browser voice playback, saved case history. |
| Migrant-support organization | Provide a consistent first-pass information workflow. | Structured fields, evidence provenance, and transparent limitations. |
| Hackathon evaluator | Test a complete workflow without private API credentials or live government access. | Synthetic demo cases and deterministic fallback behavior. |

### 2.3 Non-goals

ClearPath is intentionally **not** any of the following:

| Out of scope | Reason |
|---|---|
| Fraud detector or legal decision engine | A limited source record cannot prove intent or determine legality. |
| Government replacement | BEOE and relevant official channels remain the authoritative source. |
| Payment authorization system | The application must not make payment decisions. |
| Complaint-filing robot | No automated complaints are submitted. |
| Identity-verification service | The app does not request or validate passports, CNICs, credentials, PINs, or passwords. |
| Cloudflare bypass tool | The application does not evade CAPTCHA, bot-protection, access control, or website terms. |

---

## 3. User journey and functional workflow

The user experience is a three-step workflow: **input → confirmation → evidence**. The confirmation step is an intentional safety gate: Gemini extraction is treated as a draft, not truth.

```mermaid
flowchart TD
  A[User: typed offer or redacted file] --> B[Privacy checks and redaction confirmation]
  B --> C[Gemini structured extraction]
  C -->|Gemini unavailable or blocked| D[Local fallback parser]
  C --> E[Editable confirmed claims]
  D --> E
  E --> F[User confirms all fields]
  F --> G[BEOE source adapter]
  G -->|Approved machine-readable response| H[Live record]
  G -->|Blocked, unavailable, skipped, or no endpoint| I[Dated fallback snapshot]
  H --> J[Deterministic evidence engine]
  I --> J
  J --> K[Evidence rows and action card]
  K --> L[Constrained Gemini explanation or local fallback]
  K --> M[Optional browser voice playback]
  K --> N[Optional signed-in case saving]
```

### 3.1 Step 1 — Intake

The user can either type offer details or select a redacted document/image. The frontend warns the user not to upload passports, CNICs, payment information, account credentials, PINs, passwords, or one-time passwords. When a file is selected, the user must confirm that it is redacted before the app sends it to the extraction endpoint.

### 3.2 Step 2 — Extraction and confirmation

The backend returns a structured `Claims` object. The user can edit all fields. The app must not run evidence checking until the user confirms the reviewed extraction.

```ts
type Claims = {
  recruiterName: string;
  licenceNumber: string;
  jobTitle: string;
  country: string;
  salary: string;
  fee: string;
  deadline: string;
  urgencyClaim: string;
};
```

### 3.3 Step 3 — Evidence, explanation, and next actions

After confirmation, the backend tries the BEOE source-adapter workflow. It then produces field-level evidence rows, a source-aware action card, and—if requested—a constrained language explanation. The user can listen to the action card via the browser’s SpeechSynthesis API and can save the result to a private case history after signing in.

---

## 4. Evidence model

### 4.1 Evidence statuses

| Status | Meaning | What it does **not** mean |
|---|---|---|
| `MATCH` | A submitted confirmed claim normalized to the same value as the available comparison record. | That the full offer, recruiter, or employment arrangement has been certified. |
| `CONFLICT` | A submitted confirmed claim differs from the available comparison record. | That a person or organization committed wrongdoing. |
| `NOT FOUND` | A claim was present but no matching record existed in the limited dated fallback snapshot. | Proof that the claim is fraudulent or impossible. |
| `NOT CHECKED` | The claim or corresponding record value was unavailable for comparison. | That the claim is correct or incorrect. |

### 4.2 Deterministic status algorithm

The final evidence state is assigned by ClearPath backend code, not by Gemini. The implementation normalizes values by lowercasing and removing non-alphanumeric separators before comparison. Conceptually, the logic is:

```ts
if (!userClaim || !sourceValue) {
  status = "NOT_CHECKED";
} else if (normalise(userClaim) === normalise(sourceValue)) {
  status = "MATCH";
} else {
  status = "CONFLICT";
}
```

When no live comparison record exists, the fallback path first identifies a matching curated snapshot record by licence number or recruiter name. If the user provided a claim but there is no matching snapshot record, the status becomes `NOT FOUND`. A claim absent from the user input becomes `NOT CHECKED`.

### 4.3 Why the architecture separates AI from evidence status

Gemini is useful for extracting text from messy documents and explaining a structured result in Urdu, English, or Punjabi. It is not the authority for the final status because a language model can make unsupported inferences. ClearPath’s deterministic logic is transparent, repeatable, testable, and able to show exactly which source record and retrieval date informed each evidence row.

---

## 5. BEOE source-adapter architecture

### 5.1 Purpose

The source adapter gives ClearPath a controlled way to attempt live evidence retrieval without pretending that a public website page is a reliable API. It is designed to preserve the difference between **live evidence**, **source unavailable**, and **dated fallback**.

### 5.2 Retrieval modes and outcomes

| Source mode | Source result | Meaning in the application |
|---|---|---|
| `live` | `success` | An approved configured endpoint returned a readable record for the confirmed query. |
| `live_unavailable_fallback` | `blocked` | The official portal or endpoint returned bot-protection or access-denied behavior. No bypass is attempted. |
| `live_unavailable_fallback` | `unavailable` | The endpoint timed out, was unreadable, returned an unsupported response, or could not be reached. |
| `fallback` | `skipped` | No recruiter name or OEP licence was provided, so no lookup can be attempted. |
| `demo` | `skipped` | A deliberately synthetic demo case is being shown. |

### 5.3 Live BEOE lookup contract

If an approved machine-readable endpoint becomes available, the server may be configured with:

```text
BEOE_LOOKUP_URL=https://approved-endpoint.example/path
```

ClearPath appends confirmed `licence` and `recruiter` query parameters, sends a normal request with an eight-second timeout, and expects a JSON response matching all or part of the `Claims` schema. The backend records:

| Stored retrieval attribute | Purpose |
|---|---|
| Source mode | Distinguishes live, fallback, demo, and live-unavailable fallback. |
| Result | Stores success, not found, blocked, unavailable, or skipped. |
| Query value | Records the licence number or recruiter name used to initiate lookup. |
| Source URL and title | Shows the source consulted to the user. |
| Response status | Preserves the HTTP status when available. |
| Detail | Provides a readable explanation of source behavior. |
| Retrieval time | Preserves evidence freshness and auditability. |

### 5.4 Bot-protection boundary

The public BEOE pages may return Cloudflare or anti-bot language even with a technically successful HTTP response. ClearPath recognizes common bot-protection indicators such as “Cloudflare,” “verify you are human,” “malicious bots,” and “contact the site owner.” It labels the retrieval as blocked and falls back transparently.

> ClearPath never attempts to bypass Cloudflare, solve or evade CAPTCHA, impersonate a user, use a private authenticated session, or defeat website access controls.

### 5.5 Dated fallback snapshot

The current fallback is a small curated demonstration snapshot with a documented retrieval date, `2026-08-28`. It is not presented as a continuously synchronized BEOE database. The product displays source mode, source result, source detail, source URL, and retrieval time to prevent fallback data from being mistaken for a live government response.

---

## 6. Gemini integration

### 6.1 Gemini responsibilities

ClearPath uses the Google Gemini REST API from the **server only**. The current default model identifier in the project is `gemini-3.6-flash`.

| Gemini operation | Input | Output | Safety boundary |
|---|---|---|---|
| Structured extraction | Typed text plus optional redacted image/PDF data URL | `Claims` JSON object | Extract only explicitly stated facts; missing fields remain blank. |
| Evidence explanation | Confirmed claims, evidence rows, and action card | Language-specific explanation | Must use supplied evidence only; cannot issue an authenticity or legal verdict. |

### 6.2 Server-side request path

```text
Browser
  → tRPC mutation: clearpath.extract or clearpath.explain
  → Express/tRPC backend
  → server/clearpath.ts
  → Google Gemini generateContent REST endpoint
  → validated response
  → typed result returned to browser
```

The `GEMINI_API_KEY` is read by the backend from environment variables. It is never returned to the browser, stored in source code, or intended for public GitHub commits.

### 6.3 Extraction safeguards

Before Gemini is called, the service runs privacy-pattern checks against typed text. It identifies CNIC-like formats, passport-like references, and payment/authentication terms such as IBAN, account, card, PIN, password, or OTP. If a privacy warning exists, Gemini is not called. Instead, ClearPath returns local fallback extraction with state `privacy_blocked`.

The extraction request is configured for JSON output and includes a schema that requires all eight fields. It uses low randomness so repeated runs are more consistent. The user still must review every value.

### 6.4 Provider states

| State | Meaning | User-visible behavior |
|---|---|---|
| `connected` | Gemini returned a usable response. | Display extracted result and prompt for confirmation. |
| `missing_key` | No server-side Gemini key is configured. | Local fallback extraction/explanation is used. |
| `privacy_blocked` | Sensitive details or unconfirmed redaction prevented a call. | Gemini is not sent the material; user must redact/correct it. |
| `model_unavailable` | The configured model endpoint was not available. | Local fallback is used and the UI explains the provider issue. |
| `request_failed` | Provider request or network call failed. | Local fallback is used and disclosure remains visible. |
| `invalid_response` | Gemini response could not be parsed as usable structured content. | Local fallback is used and the user is told to review fields. |

### 6.5 Explanation guardrails

The explanation prompt asks Gemini to use evidence-based headings such as **Evidence summary**, **What matched**, **What needs attention**, **What is not checked**, and **Next official step**. It explicitly prohibits verdict and accusation language, including “genuine,” “fake,” “fraud,” “fraudulent,” “scam,” “safe,” “unsafe,” “certify,” “guarantee,” and similar claims. Gemini is instructed not to tell users whether to pay and to direct them to current official BEOE confirmation.

---

## 7. System architecture

### 7.1 High-level architecture

```text
┌──────────────────────────────────────────────────────────────┐
│                         User browser                         │
│ React 19 • Vite • Tailwind • Urdu/EN/PA UI • Speech synthesis│
└───────────────────────────┬──────────────────────────────────┘
                            │ typed tRPC calls
┌───────────────────────────▼──────────────────────────────────┐
│                     Node.js application server               │
│                   Express 4 • tRPC 11 • Zod                  │
├────────────────┬─────────────────┬───────────────────────────┤
│ ClearPath      │ Gemini client   │ BEOE source adapter       │
│ service        │ server-side     │ permitted normal request  │
│ - privacy      │ extraction and  │ - live record or          │
│ - normalization│ explanation     │ - blocked/unavailable     │
│ - rules engine │                 │ - dated fallback          │
└───────┬────────┴─────────────────┴───────────────────────────┘
        │
┌───────▼──────────────────────────────────────────────────────┐
│ Persistence and protected services                            │
│ MySQL/TiDB + Drizzle: users, cases, evidence, retrieval audit │
│ S3-compatible storage: upload bytes outside database          │
│ OAuth: signed-in private history                              │
└──────────────────────────────────────────────────────────────┘
```

### 7.2 Technology stack

| Layer | Technology in project | Responsibility |
|---|---|---|
| Frontend | React 19, Vite, TypeScript | Browser user interface and state management. |
| UI styling | Tailwind CSS 4, shadcn/ui primitives, custom CSS | Responsive Urdu-first visual experience. |
| Backend | Node.js, Express 4, TypeScript | Executes server-side business logic and protects secrets. |
| API contract | tRPC 11, Zod | Typed procedure definitions, validation, and client/server integration. |
| AI provider | Google Gemini REST API | Structured document extraction and constrained explanation. |
| Data layer | Drizzle ORM, MySQL/TiDB | Persistence of cases, evidence, retrieval logs, and document references. |
| Authentication | OAuth integration supplied by the project template | Identifies user ownership for private history. |
| Object storage | S3-compatible helper | Stores document bytes externally; database stores references. |
| Voice | Browser `SpeechSynthesis` API | Reads the action-card result aloud locally in the browser. |
| Testing | Vitest | Logic, access control, configuration, and integration tests. |

---

## 8. Repository structure and file responsibilities

| Path | Responsibility |
|---|---|
| `client/src/pages/Home.tsx` | Main application experience: language switcher, file/text intake, redaction confirmation, extraction review, evidence result, Gemini explanation, voice playback, saving, and case history. |
| `client/src/App.tsx` | React routes and global providers. |
| `client/src/main.tsx` | Browser application bootstrap. |
| `client/src/lib/trpc.ts` | Typed React client binding for backend procedures. |
| `client/src/index.css` | Warm brown/light-brown visual system, dotted globe motif, responsive layout, status panels, and lower-section outlines. |
| `client/src/components/ui/` | Reusable UI controls such as buttons, cards, badges, inputs, dialogs, and tabs. |
| `server/routers.ts` | Public/protected tRPC routes, Zod input validation, persistence operations, and upload/deletion authorization. |
| `server/clearpath.ts` | Core product service: claim types, fallback data, Gemini calls, privacy checks, normalization, BEOE adapter, deterministic evidence logic, and action cards. |
| `server/db.ts` | Ownership-scoped database helpers for case creation, listing, detail hydration, evidence/retrieval persistence, and deletions. |
| `server/storage.ts` | S3-compatible presigned upload flow and storage-reference handling. |
| `server/_core/` | Template infrastructure for Express server startup, OAuth, tRPC context, environment configuration, storage helpers, and platform integrations. |
| `drizzle/schema.ts` | Database table definitions and inferred TypeScript models. |
| `drizzle/migrations/` | Generated schema migration history. |
| `README.md` | General project, setup, safety, and submission documentation. |
| `SUBMISSION_BRIEF.md` | Presentation-oriented hackathon summary. |
| `ENV_TEMPLATE.md` | Placeholder-only environment setup guidance. |
| `server/*.test.ts` | Vitest coverage for service rules, access control, Gemini integration, and configuration. |

---

## 9. API specification

All application RPC calls are served through the typed tRPC router under the application API. Public procedures are available without sign-in; protected procedures require a valid authenticated session.

### 9.1 Public procedures

| Procedure | Input | Output | Purpose |
|---|---|---|---|
| `clearpath.demos` | None | Synthetic case list | Supplies evaluator-safe demo scenarios. |
| `clearpath.providerStatus` | None | Gemini configuration state and selected model | Makes provider configuration visible without exposing the key. |
| `clearpath.extract` | Text, optional data URL, redaction confirmation | Claims, provider, state, warnings, note | Extracts explicitly stated offer fields or falls back safely. |
| `clearpath.check` | Confirmed claims, language | Evidence rows, action card, source retrieval | Attempts source retrieval and applies deterministic comparison. |
| `clearpath.explain` | Claims, evidence rows, action card, language | Explanation, provider, state, note | Generates constrained language explanation or local fallback. |
| `auth.me` | None | Current user or empty session | Identifies whether private history is available. |
| `auth.logout` | None | Success state | Clears the session cookie. |

### 9.2 Protected procedures

| Procedure | Input | Output | Authorization requirement |
|---|---|---|---|
| `clearpath.cases` | None | User-owned case list | Signed-in user. |
| `clearpath.caseById` | Case ID | Full owned case detail | Case must belong to caller. |
| `clearpath.saveCase` | Title, language, source mode, claims, evidence, action card, retrieval | Saved case ID | Signed-in user. |
| `clearpath.uploadDocument` | Owned case ID, file metadata, data URL | Stored document reference | Case must belong to caller. |
| `clearpath.deleteDocument` | Document ID | Deletion result | Document must belong to caller. |
| `clearpath.deleteCase` | Case ID | Deletion result | Case must belong to caller. |

### 9.3 Input constraints

The API applies server-side Zod validation. Current constraints include typed offer text up to 12,000 characters and data-URL payloads up to 8,000,000 characters. Case titles, evidence statuses, languages, source modes, and retrieval fields are validated against controlled schemas before persistence.

---

## 10. Data model

### 10.1 Entity relationship overview

```mermaid
erDiagram
  USERS ||--o{ VERIFICATION_CASES : owns
  VERIFICATION_CASES ||--o{ EVIDENCE_CHECKS : contains
  VERIFICATION_CASES ||--o{ SOURCE_RETRIEVALS : records
  VERIFICATION_CASES ||--o{ CASE_DOCUMENTS : references
  USERS ||--o{ CASE_DOCUMENTS : owns
```

### 10.2 Tables

| Table | Key fields | Purpose |
|---|---|---|
| `users` | `id`, `openId`, `email`, `role`, timestamps | OAuth-backed user identity. |
| `verification_cases` | `userId`, `title`, `language`, `status`, `sourceMode`, `extractedClaims`, `actionCard` | Parent record for a saved case. |
| `evidence_checks` | `caseId`, `field`, `claim`, `status`, `explanation`, source metadata | One auditable comparison result per claim field. |
| `source_retrievals` | `caseId`, `sourceMode`, `result`, `sourceUrl`, `responseStatus`, `detail`, `retrievedAt` | Documents whether live, blocked, unavailable, fallback, or demo evidence was used. |
| `case_documents` | `caseId`, `userId`, `fileName`, `mimeType`, `storageKey`, `storageUrl` | Stores file references, not file bytes. |

### 10.3 Ownership model

User-owned case history is enforced in the API and database-helper layer. Before upload, case detail viewing, case deletion, or document deletion, the backend queries by both the authenticated `userId` and requested object ID. The app is designed so one signed-in user cannot retrieve or delete another user’s saved case or document reference.

---

## 11. File storage design

Uploaded document bytes are not stored inside database columns. The protected upload route decodes the submitted file data, uploads it via the storage helper, then stores only metadata and the returned object reference in `case_documents`.

```text
Selected redacted document
  → validated data URL
  → server-side `storagePut`
  → S3-compatible object storage
  → database stores key, URL, filename, MIME type, user ID, case ID
```

The storage key is scoped under a ClearPath/user path and is randomized by the storage helper. Case and document deletion endpoints remove the database references through ownership-scoped operations. Production storage lifecycle and object deletion policy should be reviewed separately before any public launch.

---

## 12. Privacy, security, and safety design

### 12.1 Data minimization

ClearPath requests only the offer claims needed for the checklist. It warns users not to provide high-risk identity and credential data. The product should be demonstrated with synthetic or fully redacted material.

### 12.2 Privacy controls

| Control | Implementation |
|---|---|
| CNIC-like detection | Regex detects common CNIC format in typed content. |
| Passport-like detection | Text pattern detects passport references and number-like values. |
| Payment/authentication detection | Detects terms such as IBAN, account, card, PIN, password, OTP, and Urdu equivalents. |
| Redaction acknowledgement | Required before an uploaded file is sent for AI extraction. |
| Server-only Gemini key | `GEMINI_API_KEY` is read on the backend and never sent to the frontend. |
| Protected history | Cases, uploads, and deletion routes require authentication and owner checks. |
| File-byte separation | Objects are stored externally; DB stores references rather than binary document content. |

### 12.3 Safety controls

ClearPath uses neutral language and does not call a recruiter, employer, or offer criminal, fraudulent, authentic, safe, or unsafe. The UI and Gemini prompt discourage payment under pressure and direct users to current official BEOE resources for confirmation.

### 12.4 Secrets policy

Do not commit or publicly share `GEMINI_API_KEY`, `DATABASE_URL`, `JWT_SECRET`, OAuth configuration, storage credentials, or `.env` files. Local and hosted secrets must be placed in a secure environment manager. The public repository should contain only placeholder examples and documentation.

---

## 13. Frontend and accessibility specification

### 13.1 Interface design

The current visual direction uses a warm brown/light-brown palette, generous whitespace, high-contrast dark typography, simple outlined lower information sections, and a decorative dotted-line globe motif. It is responsive across desktop and mobile layouts.

### 13.2 Language support

The primary interface language is Urdu. English and Punjabi content variants are supported for controls, action-card copy, and explanations. The selected language is passed to the backend explanation and evidence-card logic so that the resulting safety content aligns with the user interface.

### 13.3 Voice explanation

The “Explain aloud” capability uses the browser’s native SpeechSynthesis API. It reads the action card in the selected language when the browser and installed voices support it. It does not send audio to the backend and is not a separate voice-AI service.

### 13.4 Visible transparency indicators

The interface exposes the selected Gemini model/configuration state, extraction fallback state, source mode, source result, source link, retrieval time, fallback disclosure, and field-level evidence explanation. This is intentional: a user should never need to guess whether the app used live evidence, fallback data, or local extraction.

---

## 14. Local development and configuration

### 14.1 Requirements

| Requirement | Needed for |
|---|---|
| Node.js 22 or compatible current release | Application runtime and tooling. |
| pnpm 10 | Dependency installation and scripts. |
| MySQL-compatible database | Persistent case history and saved evidence. |
| `GEMINI_API_KEY` | Live Gemini extraction and explanation. Optional for synthetic/fallback demonstration. |
| Approved BEOE endpoint | Optional true live record branch. Without it, the transparent fallback path operates. |

### 14.2 Basic commands

```bash
pnpm install
pnpm dev
```

The development server prints a local URL. A reviewer can run the synthetic demo without Gemini and without a live BEOE endpoint by selecting **Try a demo case**.

### 14.3 Environment variables

```env
DATABASE_URL="your-mysql-or-tidb-connection-string"
JWT_SECRET="a-long-random-server-secret"
GEMINI_API_KEY="your-private-google-gemini-api-key"
GEMINI_MODEL="gemini-3.6-flash"
BEOE_LOOKUP_URL="https://your-approved-beoe-lookup-endpoint.example"
```

`BEOE_LOOKUP_URL` is optional. It must be an approved, machine-readable data source returning a compatible structured record. It must not point to a protected HTML page as if that page were an API.

### 14.4 Database migration

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

Review generated migration SQL before applying it to any non-disposable database. Do not use destructive schema commands against production data.

---

## 15. Testing and quality verification

### 15.1 Commands

```bash
pnpm check
pnpm test
pnpm build
```

### 15.2 Test coverage areas

| Test area | What it verifies |
|---|---|
| Evidence rules | `MATCH`, `CONFLICT`, `NOT FOUND`, and `NOT CHECKED` mapping. |
| Source adapter | Live success mapping, bot-protection blocking, network/source unavailable behavior, and dated fallback disclosure. |
| Privacy behavior | Sensitive-detail detection and blocked Gemini request path. |
| Gemini integration | Structured extraction/explanation behavior with the configured provider, without exposing the key. |
| Access control | Protected upload and deletion procedures reject unauthenticated access and enforce ownership. |
| Authentication | Session logout behavior. |
| Configuration | App title and optional legacy credential validation checks. |

### 15.3 Quality standard for a demo

A final demo should successfully show: a synthetic case, editable extracted fields, explicit confirmation, evidence rows, source/fallback disclosure, an explanation, optional speech playback, and private saved history. The presenter should explicitly state that the demo does not classify any offer as genuine or fraudulent.

---

## 16. Deployment and submission model

ClearPath is a full-stack Node application rather than a static HTML file. A hosted deployment needs a Node-compatible server, configured environment variables, database connectivity for saved history, OAuth settings for sign-in, and storage configuration for persistent uploads.

For an online hackathon submission, the recommended package is:

| Artifact | Purpose |
|---|---|
| Public GitHub repository | Primary source-code review artifact. |
| `README.md` | Setup, architecture, safety, limitations, and reviewer instructions. |
| `SUBMISSION_BRIEF.md` | Presentation-ready project narrative. |
| Short demo video | Shows the complete synthetic flow even if a judge does not run the project. |
| Hosted URL, if functioning | Convenient browser-based demonstration. |
| Synthetic fallback | Enables review without sharing private Gemini, database, OAuth, or storage credentials. |

Judges do not need Manus to read the public repository, run the code locally, or open a functioning hosted URL. They must not receive private keys or `.env` files.

---

## 17. Known limitations

| Limitation | Current behavior | Required production improvement |
|---|---|---|
| BEOE live data | Public portal may block automated access; fallback data is used transparently. | Official machine-readable data agreement or permitted endpoint. |
| Fallback record coverage | Small curated demonstration snapshot. | Governed data refresh, versioning, coverage expansion, and freshness monitoring. |
| Document truthfulness | Gemini extracts visible text but cannot prove hidden or altered terms. | Human review and verified source integrations. |
| Legal determination | No legal or fraud verdicts. | Legal review, human escalation, and formal service design. |
| User research | Prototype-focused evaluation. | Testing with workers, families, migrant-support professionals, and accessibility reviewers. |
| Language validation | Copy is provided in Urdu, English, and Punjabi. | Professional translation and usability testing for regional language variations. |
| File lifecycle | External storage references are managed by the app. | Production retention, deletion, consent, and incident-response policy. |

---

## 18. Recommended roadmap

### Phase A — Validate the prototype

Run usability sessions using only synthetic and redacted offers. Measure whether users understand the difference between `CONFLICT`, `NOT FOUND`, and `NOT CHECKED`, and whether they can find the next official action without assistance.

### Phase B — Strengthen evidence access

Obtain an approved BEOE data-access path. Define a record schema, source-version storage, retrieval retry policy, service-level monitoring, and data freshness rules. Keep the no-bypass policy even after an official agreement exists.

### Phase C — Add human escalation

Introduce an optional human-review workflow for cases with conflicting or incomplete evidence. The escalation should provide a clear scope, consent wording, response-time expectation, and privacy policy; it should not promise a legal verdict.

### Phase D — Production hardening

Conduct security review, privacy impact assessment, user testing, reliability testing, audit-log review, rate limiting, data-retention design, service monitoring, incident response planning, and independent legal review.

---

## 19. One-minute technical explanation

> “ClearPath is a React and Node.js full-stack web app. A user uploads a redacted job offer or types its details. The backend uses Gemini to extract recruiter, licence, salary, fee, job, country, deadline, and urgency claims. The user must confirm those fields. ClearPath then tries a normal permitted BEOE lookup; if the source is blocked or unavailable, the app clearly shows that and uses a dated fallback. Deterministic code—not Gemini—assigns MATCH, CONFLICT, NOT FOUND, or NOT CHECKED. The app stores sources and retrieval dates, explains the result in Urdu, English, or Punjabi, and lets signed-in users save and delete their cases.”

---

## 20. References

[1]: https://beoe.gov.pk/ "Bureau of Emigration & Overseas Employment, Government of Pakistan"

[2]: https://www.sbp.org.pk/economic-data "State Bank of Pakistan, Economic Data"

[3]: https://ai.google.dev/gemini-api/docs "Google Gemini API documentation"

