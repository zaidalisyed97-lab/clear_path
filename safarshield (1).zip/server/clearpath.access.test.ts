import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const unauthenticated = (): TrpcContext => ({
  user: null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("ClearPath protected document and case operations", () => {
  it("rejects uploads without a signed-in owner", async () => {
    const caller = appRouter.createCaller(unauthenticated());
    await expect(caller.clearpath.uploadDocument({ caseId: 1, fileName: "offer.png", mimeType: "image/png", dataUrl: "data:image/png;base64,AA==" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects document and case deletion without a signed-in owner", async () => {
    const caller = appRouter.createCaller(unauthenticated());
    await expect(caller.clearpath.deleteDocument({ id: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.clearpath.deleteCase({ id: 1 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
