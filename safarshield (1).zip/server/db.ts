import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  caseDocuments,
  evidenceChecks,
  InsertUser,
  sourceRetrievals,
  users,
  verificationCases,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createVerificationCase(
  input: typeof verificationCases.$inferInsert
) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(verificationCases).values(input);
  return Number(result[0].insertId);
}

export async function listVerificationCases(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(verificationCases)
    .where(eq(verificationCases.userId, userId))
    .orderBy(desc(verificationCases.updatedAt));
}

export async function getVerificationCase(userId: number, caseId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(verificationCases)
    .where(
      and(
        eq(verificationCases.id, caseId),
        eq(verificationCases.userId, userId)
      )
    )
    .limit(1);
  if (!rows[0]) return undefined;
  const evidence = await db
    .select()
    .from(evidenceChecks)
    .where(eq(evidenceChecks.caseId, caseId))
    .orderBy(evidenceChecks.id);
  const retrievals = await db
    .select()
    .from(sourceRetrievals)
    .where(eq(sourceRetrievals.caseId, caseId))
    .orderBy(desc(sourceRetrievals.retrievedAt));
  const documents = await db
    .select()
    .from(caseDocuments)
    .where(
      and(eq(caseDocuments.caseId, caseId), eq(caseDocuments.userId, userId))
    )
    .orderBy(desc(caseDocuments.createdAt));
  return { ...rows[0], evidence, retrievals, documents };
}

export async function addEvidenceChecks(
  caseId: number,
  checks: Array<typeof evidenceChecks.$inferInsert>
) {
  const db = await getDb();
  if (!db || checks.length === 0) return;
  await db
    .insert(evidenceChecks)
    .values(checks.map(check => ({ ...check, caseId })));
}

export async function addSourceRetrieval(
  input: typeof sourceRetrievals.$inferInsert
) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(sourceRetrievals).values(input);
  return Number(result[0].insertId);
}

export async function addCaseDocument(
  input: typeof caseDocuments.$inferInsert
) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(caseDocuments).values(input);
  return Number(result[0].insertId);
}

export async function deleteCaseDocument(userId: number, documentId: number) {
  const db = await getDb();
  if (!db) return false;
  const owned = await db
    .select({ id: caseDocuments.id })
    .from(caseDocuments)
    .where(
      and(eq(caseDocuments.id, documentId), eq(caseDocuments.userId, userId))
    )
    .limit(1);
  if (!owned[0]) return false;
  await db
    .delete(caseDocuments)
    .where(
      and(eq(caseDocuments.id, documentId), eq(caseDocuments.userId, userId))
    );
  return true;
}

export async function deleteVerificationCase(userId: number, caseId: number) {
  const db = await getDb();
  if (!db) return false;
  const owned = await db
    .select({ id: verificationCases.id })
    .from(verificationCases)
    .where(
      and(
        eq(verificationCases.id, caseId),
        eq(verificationCases.userId, userId)
      )
    )
    .limit(1);
  if (!owned[0]) return false;
  await db.delete(evidenceChecks).where(eq(evidenceChecks.caseId, caseId));
  await db.delete(sourceRetrievals).where(eq(sourceRetrievals.caseId, caseId));
  await db
    .delete(caseDocuments)
    .where(
      and(eq(caseDocuments.caseId, caseId), eq(caseDocuments.userId, userId))
    );
  await db
    .delete(verificationCases)
    .where(
      and(
        eq(verificationCases.id, caseId),
        eq(verificationCases.userId, userId)
      )
    );
  return true;
}
