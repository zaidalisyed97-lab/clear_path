export type Language = "ur" | "en" | "pa";
export type EvidenceStatus = "MATCH" | "CONFLICT" | "NOT_FOUND" | "NOT_CHECKED";
export type SourceMode =
  | "live"
  | "fallback"
  | "live_unavailable_fallback"
  | "demo";
export type SourceResult =
  | "success"
  | "not_found"
  | "blocked"
  | "unavailable"
  | "skipped";
export type GeminiState =
  | "connected"
  | "missing_key"
  | "privacy_blocked"
  | "model_unavailable"
  | "request_failed"
  | "invalid_response";

export type Claims = {
  recruiterName: string;
  licenceNumber: string;
  jobTitle: string;
  country: string;
  salary: string;
  fee: string;
  deadline: string;
  urgencyClaim: string;
};

export type EvidenceRow = {
  field: keyof Claims;
  label: string;
  claim: string;
  status: EvidenceStatus;
  explanation: string;
  sourceUrl: string;
  sourceTitle: string;
  retrievedAt: string;
};

export type SourceRetrieval = {
  sourceMode: SourceMode;
  result: SourceResult;
  queryValue?: string;
  sourceUrl: string;
  sourceTitle: string;
  responseStatus?: number;
  detail: string;
  retrievedAt: string;
  fallbackUsed: boolean;
};

export const SNAPSHOT_RETRIEVED_AT = "2026-08-28";
export const BEOE_SNAPSHOT: Array<Partial<Claims>> = [
  {
    recruiterName: "Bright Future Recruiting",
    licenceNumber: "OEP-1823/LHR",
    jobTitle: "Electrician",
    country: "Qatar",
    salary: "1800 QAR",
    fee: "PKR 180,000",
    deadline: "Application closes Friday",
    urgencyClaim: "Limited seats mentioned, no immediate payment request",
  },
];

export const CLEARPATH_SOURCE_LINKS = {
  jobs: "https://beoe.gov.pk/foreign-jobs",
  oeps: "https://beoe.gov.pk/list-of-oeps?show=active",
  complaints: "https://beoe.gov.pk/complaints",
  illegal: "https://beoe.gov.pk/index.php/illegal-recruitment",
  fees: "https://beoe.gov.pk/fee-structure-emigrant",
};

const LIVE_BEOE_OEP_URL = "https://beoe.gov.pk/list-of-oeps?show=active";
const DEFAULT_GEMINI_MODEL = "gemini-3.6-flash";

export const demoCases: Array<{
  id: string;
  title: string;
  claims: Claims;
  sourceMode: "demo";
}> = [
  {
    id: "demo-pressure",
    title: "Saudi driver offer · pressure to pay",
    sourceMode: "demo",
    claims: {
      recruiterName: "Al Noor Overseas Employment",
      licenceNumber: "OEP-4821/KAR",
      jobTitle: "Heavy Vehicle Driver",
      country: "Saudi Arabia",
      salary: "1500 SAR",
      fee: "PKR 385,000 processing fee",
      deadline: "Pay today or seat cancelled",
      urgencyClaim: "Immediate payment demanded through WhatsApp",
    },
  },
  {
    id: "demo-mixed",
    title: "Qatar electrician offer · mixed evidence",
    sourceMode: "demo",
    claims: {
      recruiterName: "Bright Future Recruiting",
      licenceNumber: "OEP-1823/LHR",
      jobTitle: "Electrician",
      country: "Qatar",
      salary: "1800 QAR",
      fee: "PKR 180,000",
      deadline: "Application closes Friday",
      urgencyClaim: "Limited seats mentioned, no immediate payment request",
    },
  },
];

export function emptyClaims(): Claims {
  return {
    recruiterName: "",
    licenceNumber: "",
    jobTitle: "",
    country: "",
    salary: "",
    fee: "",
    deadline: "",
    urgencyClaim: "",
  };
}

function clean(value: unknown) {
  return String(value ?? "")
    .trim()
    .replace(/\s+/g, " ");
}

export function privacyWarnings(text: string): string[] {
  const warnings: string[] = [];
  if (/\b\d{5}-\d{7}-\d\b/.test(text))
    warnings.push("CNIC-like number detected");
  if (
    /(passport|پاسپورٹ)\s*(no|number|نمبر)?\s*[:#-]?\s*[A-Z0-9]{5,}/i.test(text)
  )
    warnings.push("passport-like detail detected");
  if (
    /(?:iban|account|card|pin|password|otp|اکاؤنٹ|پن|پاس ورڈ|او ٹی پی)/i.test(
      text
    )
  )
    warnings.push("payment or authentication detail detected");
  return warnings;
}

export function normalizeClaims(input: Partial<Claims>): Claims {
  return {
    recruiterName: clean(input.recruiterName),
    licenceNumber: clean(input.licenceNumber),
    jobTitle: clean(input.jobTitle),
    country: clean(input.country),
    salary: clean(input.salary),
    fee: clean(input.fee),
    deadline: clean(input.deadline),
    urgencyClaim: clean(input.urgencyClaim),
  };
}

export function fallbackExtract(text: string): Claims {
  const source = text || "";
  const find = (patterns: RegExp[]) => {
    for (const pattern of patterns) {
      const match = source.match(pattern);
      if (match?.[1]) return clean(match[1]);
    }
    return "";
  };
  return normalizeClaims({
    recruiterName: find([
      /(?:recruiter|agency|company|ایجنسی)\s*[:\-]\s*(.+)/i,
    ]),
    licenceNumber: find([
      /(?:oep\s+)?licen[cs]e(?:\s*(?:no\.?|number))?\s*[:\-]\s*([A-Z0-9\-/]+)/i,
      /\boep\s*[:\-]\s*([A-Z0-9\-/]+)/i,
    ]),
    jobTitle: find([/(?:job|position|designation|عہدہ)\s*[:\-]\s*(.+)/i]),
    country: find([/(?:country|location|ملک)\s*[:\-]\s*(.+)/i]),
    salary: find([/(?:salary|pay|تنخواہ)\s*[:\-]\s*(.+)/i]),
    fee: find([/(?:fee|processing fee|فیس)\s*[:\-]\s*(.+)/i]),
    deadline: find([/(?:deadline|last date|آخری تاریخ)\s*[:\-]\s*(.+)/i]),
    urgencyClaim:
      find([/(?:urgent|urgency|pay today|فوری)\s*[:\-]?\s*(.+)/i]) ||
      (/(pay today|immediately|فوری|آج ادائیگی)/i.test(source)
        ? "Immediate payment language detected"
        : ""),
  });
}

const CLEARPATH_LABELS: Record<keyof Claims, string> = {
  recruiterName: "Recruiter / agency",
  licenceNumber: "OEP licence",
  jobTitle: "Job title",
  country: "Country",
  salary: "Salary",
  fee: "Requested fee",
  deadline: "Deadline",
  urgencyClaim: "Urgency claim",
};

function normalized(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function findSnapshotRecord(claims: Claims) {
  return BEOE_SNAPSHOT.find(
    record =>
      (claims.licenceNumber &&
        normalized(String(record.licenceNumber ?? "")) ===
          normalized(claims.licenceNumber)) ||
      (claims.recruiterName &&
        normalized(String(record.recruiterName ?? "")) ===
          normalized(claims.recruiterName))
  );
}

function safeSourceDetail(status: number | undefined, body: string) {
  if (
    status === 401 ||
    status === 403 ||
    /contact the site owner|cloudflare|verify you are human|malicious bots/i.test(
      body
    )
  ) {
    return "The official BEOE portal did not permit this automated lookup. No bot-protection bypass was attempted.";
  }
  if (status === 404)
    return "The official lookup page was not available at the expected address.";
  return "The official BEOE portal could not be reached for this lookup. No automated verification result was created.";
}

function hasBotProtectionMessage(body: string) {
  return /contact the site owner|cloudflare|verify you are human|malicious bots/i.test(
    body
  );
}

export async function retrieveBEOERecord(
  claims: Claims
): Promise<{ record?: Partial<Claims>; retrieval: SourceRetrieval }> {
  const queryValue = claims.licenceNumber || claims.recruiterName;
  const retrievedAt = new Date().toISOString();
  if (!queryValue) {
    return {
      retrieval: {
        sourceMode: "fallback",
        result: "skipped",
        sourceUrl: LIVE_BEOE_OEP_URL,
        sourceTitle:
          "Bureau of Emigration & Overseas Employment · official OEP list",
        detail:
          "A recruiter name or OEP licence number is required before a public-source lookup can be attempted.",
        retrievedAt,
        fallbackUsed: true,
      },
    };
  }

  const configuredEndpoint = process.env.BEOE_LOOKUP_URL;
  if (configuredEndpoint) {
    try {
      const url = new URL(configuredEndpoint);
      url.searchParams.set("licence", claims.licenceNumber);
      url.searchParams.set("recruiter", claims.recruiterName);
      const response = await fetch(url, {
        headers: { Accept: "application/json,text/html;q=0.9" },
        signal: AbortSignal.timeout(8_000),
      });
      const body = await response.text();
      if (response.ok && body.trim() && !hasBotProtectionMessage(body)) {
        const parsed = JSON.parse(body) as Partial<Claims>;
        return {
          record: normalizeClaims(parsed),
          retrieval: {
            sourceMode: "live",
            result: "success",
            queryValue,
            sourceUrl: url.toString(),
            sourceTitle: "BEOE approved lookup endpoint",
            responseStatus: response.status,
            detail:
              "A configured approved source returned a live response for this case.",
            retrievedAt,
            fallbackUsed: false,
          },
        };
      }
      return {
        retrieval: {
          sourceMode: "live_unavailable_fallback",
          result:
            response.status === 401 ||
            response.status === 403 ||
            hasBotProtectionMessage(body)
              ? "blocked"
              : "unavailable",
          queryValue,
          sourceUrl: url.toString(),
          sourceTitle: "BEOE approved lookup endpoint",
          responseStatus: response.status,
          detail: safeSourceDetail(response.status, body),
          retrievedAt,
          fallbackUsed: true,
        },
      };
    } catch {
      return {
        retrieval: {
          sourceMode: "live_unavailable_fallback",
          result: "unavailable",
          queryValue,
          sourceUrl: configuredEndpoint,
          sourceTitle: "BEOE approved lookup endpoint",
          detail:
            "The configured live lookup timed out or returned an unreadable response. No bypass was attempted.",
          retrievedAt,
          fallbackUsed: true,
        },
      };
    }
  }

  try {
    const response = await fetch(LIVE_BEOE_OEP_URL, {
      headers: { Accept: "text/html,application/xhtml+xml" },
      signal: AbortSignal.timeout(8_000),
    });
    const body = await response.text();
    return {
      retrieval: {
        sourceMode: "live_unavailable_fallback",
        result:
          response.status === 401 ||
          response.status === 403 ||
          hasBotProtectionMessage(body)
            ? "blocked"
            : "unavailable",
        queryValue,
        sourceUrl: LIVE_BEOE_OEP_URL,
        sourceTitle:
          "Bureau of Emigration & Overseas Employment · official OEP list",
        responseStatus: response.status,
        detail: hasBotProtectionMessage(body)
          ? safeSourceDetail(response.status, body)
          : response.ok
          ? "The official public page did not expose a permitted machine-readable licence lookup. A dated fallback is shown instead."
          : safeSourceDetail(response.status, body),
        retrievedAt,
        fallbackUsed: true,
      },
    };
  } catch {
    return {
      retrieval: {
        sourceMode: "live_unavailable_fallback",
        result: "unavailable",
        queryValue,
        sourceUrl: LIVE_BEOE_OEP_URL,
        sourceTitle:
          "Bureau of Emigration & Overseas Employment · official OEP list",
        detail:
          "The official BEOE portal could not be reached from ClearPath. A dated fallback is shown instead.",
        retrievedAt,
        fallbackUsed: true,
      },
    };
  }
}

export function checkEvidence(claims: Claims): EvidenceRow[] {
  const snapshot = findSnapshotRecord(claims);
  return (Object.keys(CLEARPATH_LABELS) as Array<keyof Claims>).map(field => {
    const claim = claims[field];
    let status: EvidenceStatus = "NOT_CHECKED";
    const snapshotValue = snapshot?.[field];
    if (claim && !snapshot) status = "NOT_FOUND";
    else if (claim && snapshotValue)
      status =
        normalized(String(snapshotValue)) === normalized(claim)
          ? "MATCH"
          : "CONFLICT";
    const sourceUrl =
      field === "licenceNumber" || field === "recruiterName"
        ? CLEARPATH_SOURCE_LINKS.oeps
        : field === "urgencyClaim" || field === "fee"
          ? CLEARPATH_SOURCE_LINKS.illegal
          : CLEARPATH_SOURCE_LINKS.jobs;
    const explanation =
      status === "MATCH"
        ? "This claim matched the limited dated demo snapshot."
        : status === "CONFLICT"
          ? "This claim needs attention because it does not align with safe verification guidance."
          : status === "NOT_FOUND"
            ? "No matching record was found in the limited dated demo snapshot; absence is not proof of wrongdoing."
            : "This field was not independently checked in the demo snapshot.";
    return {
      field,
      label: CLEARPATH_LABELS[field],
      claim: claim || "—",
      status,
      explanation,
      sourceUrl,
      sourceTitle:
        "Bureau of Emigration & Overseas Employment · dated demo snapshot",
      retrievedAt: SNAPSHOT_RETRIEVED_AT,
    };
  });
}

export function checkEvidenceWithRecord(
  claims: Claims,
  record: Partial<Claims> | undefined,
  retrieval: SourceRetrieval
): EvidenceRow[] {
  if (!record) {
    return checkEvidence(claims).map(row => ({
      ...row,
      sourceUrl: retrieval.sourceUrl,
      sourceTitle: retrieval.sourceTitle,
      retrievedAt: retrieval.retrievedAt,
      explanation: `${row.explanation} ${retrieval.detail}`,
    }));
  }

  return (Object.keys(CLEARPATH_LABELS) as Array<keyof Claims>).map(field => {
    const claim = claims[field];
    const sourceValue = record[field];
    const status: EvidenceStatus =
      !claim || !sourceValue
        ? "NOT_CHECKED"
        : normalized(String(sourceValue)) === normalized(claim)
          ? "MATCH"
          : "CONFLICT";
    const explanation =
      status === "MATCH"
        ? "This claim matched the returned live source record."
        : status === "CONFLICT"
          ? "This claim differs from the returned live source record and needs human review."
          : "This field was not available in the returned live source record.";
    return {
      field,
      label: CLEARPATH_LABELS[field],
      claim: claim || "—",
      status,
      explanation,
      sourceUrl: retrieval.sourceUrl,
      sourceTitle: retrieval.sourceTitle,
      retrievedAt: retrieval.retrievedAt,
    };
  });
}

export function makeActionCard(
  rows: EvidenceRow[],
  language: Language,
  retrieval?: SourceRetrieval
) {
  const conflicts = rows.filter(row => row.status === "CONFLICT").length;
  const missing = rows.filter(row => row.status === "NOT_FOUND").length;
  const headline =
    language === "ur"
      ? "ادائیگی سے پہلے ثبوت دیکھیں"
      : language === "pa"
        ? "ادائیگی توں پہلاں ثبوت ویکھو"
        : "Review evidence before paying";
  const sourceNote = retrieval?.fallbackUsed
    ? language === "ur"
      ? "لائیو سرکاری ریکارڈ دستیاب نہیں تھا، اس لیے تاریخ شدہ fallback استعمال ہوا۔"
      : language === "pa"
        ? "لائیو سرکاری ریکارڈ دستیاب نئیں سی، ایس لئی تاریخ شدہ fallback ورتیا گیا۔"
        : "A live official record was unavailable, so a dated fallback was used."
    : "";
  const summary =
    language === "ur"
      ? `اس کیس میں ${conflicts} متضاد اور ${missing} غیر موجود ریکارڈ ملا۔ ${sourceNote} یہ نتیجہ کسی نوکری کو اصلی یا جعلی قرار نہیں دیتا۔`
      : language === "pa"
        ? `ایس کیس وچ ${conflicts} متضاد تے ${missing} نہ لبھے ریکارڈ ملے۔ ${sourceNote} ایہہ نتیجہ نوکری نوں اصلی یا جعلی قرار نہیں دیندا۔`
        : `This case has ${conflicts} conflicting and ${missing} not-found records. ${sourceNote} This result does not declare the job genuine or fraudulent.`;
  const next =
    language === "ur"
      ? "سرکاری BEOE پورٹل پر موجودہ لائسنس، جاب آرڈر اور فیس خود تصدیق کریں۔ جلدی میں ادائیگی نہ کریں اور پاسپورٹ، CNIC یا PIN اپ لوڈ نہ کریں۔"
      : language === "pa"
        ? "سرکاری BEOE پورٹل تے موجودہ لائسنس، جاب آرڈر تے فیس خود چیک کرو۔ جلدی وچ ادائیگی نہ کرو تے پاسپورٹ، CNIC یا PIN اپ لوڈ نہ کرو۔"
        : "Confirm the current licence, job order, and fee through the official BEOE portal. Do not pay under pressure, and never upload a passport, CNIC, PIN, or password.";
  return {
    headline,
    summary,
    next,
    sourceUrl: retrieval?.sourceUrl ?? CLEARPATH_SOURCE_LINKS.oeps,
    sourceTitle:
      retrieval?.sourceTitle ??
      "Bureau of Emigration & Overseas Employment · dated demo snapshot",
    retrievedAt: retrieval?.retrievedAt ?? SNAPSHOT_RETRIEVED_AT,
    reviewedAt: new Date().toISOString(),
    sourceMode: retrieval?.sourceMode ?? "demo",
    sourceResult: retrieval?.result ?? "skipped",
    fallbackUsed: retrieval?.fallbackUsed ?? true,
    sourceDetail:
      retrieval?.detail ?? "A dated demo snapshot was used for this review.",
  };
}

type ClearPathGeminiInput = {
  text: string;
  imageDataUrl?: string;
  redactedConfirmed?: boolean;
};
type ClearPathGeminiResult = {
  claims: Claims;
  provider: "gemini" | "fallback";
  state: GeminiState;
  note?: string;
  warnings: string[];
};

export function geminiStatus() {
  const configured = Boolean(process.env.GEMINI_API_KEY);
  return {
    configured,
    model: process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL,
    provider: "Gemini",
    detail: configured
      ? "Gemini is configured. Each request is validated before it is used."
      : "Gemini is not configured; ClearPath will use local fallback extraction and explanation.",
  };
}

function parseGeminiText(payload: unknown): string {
  const candidate = payload as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  return (
    candidate.candidates?.[0]?.content?.parts
      ?.map(part => part.text ?? "")
      .join("")
      .trim() ?? ""
  );
}

function cleanJsonText(raw: string) {
  return raw
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function filePartFromDataUrl(imageDataUrl: string) {
  const match = imageDataUrl.match(
    /^data:((?:image\/[a-z0-9.+-]+)|(?:application\/pdf));base64,(.+)$/i
  );
  return match ? { inlineData: { mimeType: match[1], data: match[2] } } : null;
}

export async function extractWithGemini(
  input: ClearPathGeminiInput
): Promise<ClearPathGeminiResult> {
  const apiKey = process.env.GEMINI_API_KEY;
  const warnings = privacyWarnings(input.text);
  if (input.imageDataUrl && !input.redactedConfirmed)
    warnings.push("upload redaction was not confirmed");
  if (!apiKey || warnings.length > 0)
    return {
      claims: fallbackExtract(input.text),
      provider: "fallback",
      state: warnings.length > 0 ? "privacy_blocked" : "missing_key",
      note:
        warnings.length > 0
          ? `Sensitive details were not sent to Gemini: ${warnings.join(", ")}.`
          : "Gemini is not configured; fallback extraction used.",
      warnings,
    };

  try {
    const parts: Array<Record<string, unknown>> = [
      {
        text: `Extract only explicitly stated fields from this overseas-job offer. Never infer or judge authenticity. Return empty strings when a field is absent. Fields: recruiterName, licenceNumber, jobTitle, country, salary, fee, deadline, urgencyClaim. Text:\n${input.text}`,
      },
    ];
    if (input.imageDataUrl) {
      const imagePart = filePartFromDataUrl(input.imageDataUrl);
      if (imagePart) parts.push(imagePart);
    }
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: "You are a precise, conservative document extraction service. Extract only visible or explicitly written facts. Do not call an offer genuine, fake, fraudulent, safe, or unsafe.",
              },
            ],
          },
          contents: [{ role: "user", parts }],
          generationConfig: {
            temperature: 0,
            responseMimeType: "application/json",
            responseSchema: {
              type: "OBJECT",
              properties: {
                recruiterName: { type: "STRING" },
                licenceNumber: { type: "STRING" },
                jobTitle: { type: "STRING" },
                country: { type: "STRING" },
                salary: { type: "STRING" },
                fee: { type: "STRING" },
                deadline: { type: "STRING" },
                urgencyClaim: { type: "STRING" },
              },
              required: [
                "recruiterName",
                "licenceNumber",
                "jobTitle",
                "country",
                "salary",
                "fee",
                "deadline",
                "urgencyClaim",
              ],
            },
          },
        }),
      }
    );
    if (!response.ok)
      return {
        claims: fallbackExtract(input.text),
        provider: "fallback",
        state: response.status === 404 ? "model_unavailable" : "request_failed",
        note: `Gemini extraction could not run (${response.status}). Fallback extraction is active; review all fields.`,
        warnings: [],
      };
    const payload = await response.json();
    const raw = cleanJsonText(parseGeminiText(payload));
    if (!raw)
      return {
        claims: fallbackExtract(input.text),
        provider: "fallback",
        state: "invalid_response",
        note: "Gemini returned no readable structured result. Fallback extraction is active; review all fields.",
        warnings: [],
      };
    const claims = normalizeClaims(JSON.parse(raw) as Partial<Claims>);
    return {
      claims,
      provider: "gemini",
      state: "connected",
      note: `Gemini extracted visible fields using ${process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL}. Confirm every field before checking.`,
      warnings: [],
    };
  } catch {
    return {
      claims: fallbackExtract(input.text),
      provider: "fallback",
      state: "request_failed",
      note: "Gemini could not be reached or returned unreadable data. Fallback extraction is active; review all fields.",
      warnings: [],
    };
  }
}

export async function extractWithQwen(
  input: ClearPathGeminiInput
): Promise<ClearPathGeminiResult> {
  return extractWithGemini(input);
}

export async function explainWithGemini(input: {
  claims: Claims;
  evidence: EvidenceRow[];
  actionCard: ReturnType<typeof makeActionCard>;
  language: Language;
}): Promise<{
  explanation: string;
  provider: "gemini" | "fallback";
  state: GeminiState;
  note: string;
}> {
  const fallback =
    input.language === "ur"
      ? "یہ رپورٹ دستیاب ثبوت اور غیر یقینی کو سادہ انداز میں دکھاتی ہے۔ ہر ریکارڈ کی تازہ تصدیق سرکاری BEOE پورٹل سے کریں۔ یہ کسی نوکری کو اصلی یا جعلی قرار نہیں دیتی۔"
      : input.language === "pa"
        ? "ایہہ رپورٹ موجود ثبوت تے غیر یقینی نوں سادہ طریقے نال سمجھاندی اے۔ ہر ریکارڈ نوں سرکاری BEOE پورٹل تے تازہ چیک کرو۔ ایہہ نوکری نوں اصلی یا جعلی قرار نہیں دیندی۔"
        : "This explanation summarizes the available evidence and uncertainty. Confirm each record through the official BEOE portal. It does not declare an offer genuine or fraudulent.";
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey)
    return {
      explanation: fallback,
      provider: "fallback",
      state: "missing_key",
      note: "Gemini is not configured; ClearPath generated the local safety explanation.",
    };
  try {
    const languageName =
      input.language === "ur"
        ? "Urdu"
        : input.language === "pa"
          ? "Punjabi"
          : "English";
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [
              {
                text: `Explain this evidence report in clear ${languageName}. Use only the headings: Evidence summary, What matched, What needs attention, What is not checked, Next official step. State facts from the supplied evidence only. Do not use these words or their translations: genuine, fake, fraud, fraudulent, certify, certification, safe, unsafe, scam, guarantee, valid, invalid. Do not accuse any person or company. Do not tell the user to pay or not pay. Say that each record needs current confirmation through the official BEOE portal and that a dated fallback may be incomplete.`,
              },
            ],
          },
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: JSON.stringify({
                    claims: input.claims,
                    evidence: input.evidence,
                    actionCard: input.actionCard,
                  }),
                },
              ],
            },
          ],
          generationConfig: { temperature: 0.2 },
        }),
      }
    );
    if (!response.ok)
      return {
        explanation: fallback,
        provider: "fallback",
        state: response.status === 404 ? "model_unavailable" : "request_failed",
        note: `Gemini explanation could not run (${response.status}); ClearPath generated the local safety explanation.`,
      };
    const explanation = parseGeminiText(await response.json());
    return explanation
      ? {
          explanation,
          provider: "gemini",
          state: "connected",
          note: `Gemini generated this explanation using ${process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL}.`,
        }
      : {
          explanation: fallback,
          provider: "fallback",
          state: "invalid_response",
          note: "Gemini returned no readable explanation; ClearPath generated the local safety explanation.",
        };
  } catch {
    return {
      explanation: fallback,
      provider: "fallback",
      state: "request_failed",
      note: "Gemini could not be reached; ClearPath generated the local safety explanation.",
    };
  }
}
