import { describe, expect, it } from "vitest";

describe("ClearPath app title", () => {
  it("uses the configured public title", () => {
    expect(process.env.VITE_APP_TITLE).toBe("ClearPath");
  });
});
