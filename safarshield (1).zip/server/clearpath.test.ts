import { afterEach, describe, expect, it, vi } from "vitest";
import { checkEvidence, checkEvidenceWithRecord, demoCases, fallbackExtract, makeActionCard, privacyWarnings, retrieveBEOERecord } from "./clearpath";

afterEach(() => {
  vi.restoreAllMocks();
  delete process.env.BEOE_LOOKUP_URL;
});

describe("ClearPath evidence engine", () => {
  it("keeps unknown claims neutral instead of declaring an offer fake", () => {
    const rows = checkEvidence({ recruiterName: "", licenceNumber: "", jobTitle: "", country: "", salary: "", fee: "", deadline: "", urgencyClaim: "" });
    expect(rows.every(row => row.status === "NOT_CHECKED")).toBe(true);
    expect(makeActionCard(rows, "en").summary).toContain("does not declare the job genuine or fraudulent");
  });

  it("extracts typed demo labels without requiring the model", () => {
    const claims = fallbackExtract("Recruiter: Bright Future Recruiting\nOEP licence: OEP-1823/LHR\nJob: Electrician\nCountry: Qatar\nSalary: 1800 QAR");
    expect(claims.recruiterName).toContain("Bright Future Recruiting");
    expect(claims.licenceNumber).toBe("OEP-1823/LHR");
    expect(claims.country).toBe("Qatar");
  });

  it("maps every known demo field through the dated structured snapshot", () => {
    const rows = checkEvidence(demoCases[1]!.claims);
    expect(rows.filter(row => row.status === "MATCH").length).toBeGreaterThanOrEqual(5);
    expect(rows.find(row => row.field === "fee")?.status).toBe("MATCH");
    expect(rows.every(row => row.retrievedAt === "2026-08-28")).toBe(true);
  });

  it("warns before sensitive identifiers can reach Gemini", () => {
    expect(privacyWarnings("CNIC 35202-1234567-1 and PIN 1234").length).toBeGreaterThan(0);
  });

  it("ships synthetic cases for demo resilience", () => {
    expect(demoCases.length).toBeGreaterThan(0);
    expect(demoCases[0]?.sourceMode).toBe("demo");
  });

  it("does not bypass a protected BEOE portal and exposes a dated fallback instead", async () => {
    const fetchMock = vi.spyOn(global, "fetch").mockResolvedValue(new Response('{"message":"Please contact the site owner for access."}', { status: 403 }));
    const { retrieval } = await retrieveBEOERecord(demoCases[1]!.claims);
    const rows = checkEvidenceWithRecord(demoCases[1]!.claims, undefined, retrieval);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(retrieval.result).toBe("blocked");
    expect(retrieval.sourceMode).toBe("live_unavailable_fallback");
    expect(retrieval.fallbackUsed).toBe(true);
    expect(retrieval.detail).toMatch(/No bot-protection bypass was attempted/i);
    expect(rows[0]?.sourceUrl).toBe(retrieval.sourceUrl);
  });

  it("treats a successful HTTP response carrying bot-protection text as blocked", async () => {
    vi.spyOn(global, "fetch").mockResolvedValue(new Response("This website uses security to protect against malicious bots. Please contact the site owner for access.", { status: 200 }));
    const { retrieval } = await retrieveBEOERecord(demoCases[1]!.claims);

    expect(retrieval.result).toBe("blocked");
    expect(retrieval.fallbackUsed).toBe(true);
    expect(retrieval.detail).toMatch(/No bot-protection bypass was attempted/i);
  });

  it("uses the dated fallback transparently when the BEOE source is unreachable", async () => {
    vi.spyOn(global, "fetch").mockRejectedValue(new Error("network unavailable"));
    const { retrieval } = await retrieveBEOERecord(demoCases[1]!.claims);
    const rows = checkEvidenceWithRecord(demoCases[1]!.claims, undefined, retrieval);
    const actionCard = makeActionCard(rows, "en", retrieval);

    expect(retrieval.result).toBe("unavailable");
    expect(retrieval.sourceMode).toBe("live_unavailable_fallback");
    expect(retrieval.fallbackUsed).toBe(true);
    expect(actionCard.summary).toContain("live official record was unavailable");
  });

  it("uses a configured approved endpoint only when it returns machine-readable record data", async () => {
    process.env.BEOE_LOOKUP_URL = "https://approved.example/lookup";
    vi.spyOn(global, "fetch").mockResolvedValue(new Response(JSON.stringify(demoCases[1]!.claims), { status: 200 }));

    const { record, retrieval } = await retrieveBEOERecord(demoCases[1]!.claims);
    const rows = checkEvidenceWithRecord(demoCases[1]!.claims, record, retrieval);

    expect(retrieval.sourceMode).toBe("live");
    expect(retrieval.result).toBe("success");
    expect(retrieval.fallbackUsed).toBe(false);
    expect(rows.filter(row => row.status === "MATCH").length).toBeGreaterThanOrEqual(5);
  });
});
