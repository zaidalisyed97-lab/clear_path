import { describe, expect, it } from "vitest";
import { checkEvidence, emptyClaims, explainWithGemini, extractWithGemini, makeActionCard } from "./clearpath";

describe("ClearPath Gemini integration", () => {
  it("extracts harmless typed offer details through the configured Gemini model", async () => {
    const result = await extractWithGemini({
      text: "Recruiter: Bright Future Recruiting\nOEP licence: OEP-1823/LHR\nJob: Electrician\nCountry: Qatar\nSalary: 1800 QAR\nFee: PKR 180,000",
      redactedConfirmed: true,
    });

    expect(result.provider).toBe("gemini");
    expect(result.claims.licenceNumber).toContain("OEP-1823");
    expect(result.warnings).toEqual([]);
  }, 30_000);

  it("returns a neutral evidence explanation through the configured Gemini model", async () => {
    const claims = {
      ...emptyClaims(),
      recruiterName: "Bright Future Recruiting",
      licenceNumber: "OEP-1823/LHR",
      jobTitle: "Electrician",
      country: "Qatar",
      salary: "1800 QAR",
      fee: "PKR 180,000",
    };
    const evidence = checkEvidence(claims);
    const result = await explainWithGemini({
      claims,
      evidence,
      actionCard: makeActionCard(evidence, "en"),
      language: "en",
    });

    expect(result.provider).toBe("gemini");
    expect(result.explanation).not.toMatch(/genuine|fake|fraud|fraudulent|certif|safe|unsafe|scam|guarantee|\bvalid\b|\binvalid\b/i);
  }, 30_000);
});
