import { describe, expect, it } from "vitest";

describe("Gemini credential", () => {
  it("is accepted by the Gemini models endpoint when configured", async () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return;

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`);
    expect(response.ok).toBe(true);
    const payload = await response.json() as { models?: unknown[] };
    expect(Array.isArray(payload.models)).toBe(true);
  }, 15_000);
});
