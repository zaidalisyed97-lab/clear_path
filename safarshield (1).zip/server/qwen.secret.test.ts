import { describe, expect, it } from "vitest";

describe("Legacy DASHSCOPE_API_KEY", () => {
  it("can authenticate to the lightweight Model Studio models endpoint when configured as an optional legacy secret", async () => {
    const apiKey = process.env.DASHSCOPE_API_KEY;
    if (!apiKey) return;

    const response = await fetch("https://dashscope-intl.aliyuncs.com/compatible-mode/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(response.ok).toBe(true);
  }, 15000);
});
