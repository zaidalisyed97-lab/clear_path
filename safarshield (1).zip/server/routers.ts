import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  addCaseDocument,
  addEvidenceChecks,
  addSourceRetrieval,
  createVerificationCase,
  deleteCaseDocument,
  deleteVerificationCase,
  getVerificationCase,
  listVerificationCases,
} from "./db";
import {
  checkEvidenceWithRecord,
  demoCases,
  extractWithGemini,
  explainWithGemini,
  geminiStatus,
  makeActionCard,
  normalizeClaims,
  retrieveBEOERecord,
} from "./clearpath";
import { storagePut } from "./storage";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  clearpath: router({
    demos: publicProcedure.query(() => demoCases),
    providerStatus: publicProcedure.query(() => geminiStatus()),
    extract: publicProcedure
      .input(
        z.object({
          text: z.string().max(12000).default(""),
          imageDataUrl: z.string().max(8_000_000).optional(),
          redactedConfirmed: z.boolean().default(false),
        })
      )
      .mutation(async ({ input }) => extractWithGemini(input)),
    explain: publicProcedure
      .input(
        z.object({
          claims: z.record(z.string(), z.string()),
          evidence: z.array(
            z.object({
              field: z.string(),
              label: z.string(),
              claim: z.string(),
              status: z.enum(["MATCH", "CONFLICT", "NOT_FOUND", "NOT_CHECKED"]),
              explanation: z.string(),
              sourceUrl: z.string(),
              sourceTitle: z.string(),
              retrievedAt: z.string(),
            })
          ),
          actionCard: z.unknown(),
          language: z.enum(["ur", "en", "pa"]).default("ur"),
        })
      )
      .mutation(({ input }) =>
        explainWithGemini({
          claims: normalizeClaims(input.claims),
          evidence: input.evidence as Parameters<
            typeof explainWithGemini
          >[0]["evidence"],
          actionCard: input.actionCard as Parameters<
            typeof explainWithGemini
          >[0]["actionCard"],
          language: input.language,
        })
      ),
    check: publicProcedure
      .input(
        z.object({
          claims: z.record(z.string(), z.string()),
          language: z.enum(["ur", "en", "pa"]).default("ur"),
        })
      )
      .mutation(async ({ input }) => {
        const claims = normalizeClaims(input.claims);
        const { record, retrieval } = await retrieveBEOERecord(claims);
        const evidence = checkEvidenceWithRecord(claims, record, retrieval);
        return {
          claims,
          evidence,
          actionCard: makeActionCard(evidence, input.language, retrieval),
          retrieval,
        };
      }),
    cases: protectedProcedure.query(async ({ ctx }) =>
      listVerificationCases(ctx.user.id)
    ),
    caseById: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ ctx, input }) =>
        getVerificationCase(ctx.user.id, input.id)
      ),
    saveCase: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1).max(180),
          language: z.enum(["ur", "en", "pa"]),
          sourceMode: z.enum(["typed", "upload", "demo"]),
          claims: z.record(z.string(), z.string()),
          evidence: z.array(
            z.object({
              field: z.string(),
              claim: z.string(),
              status: z.enum(["MATCH", "CONFLICT", "NOT_FOUND", "NOT_CHECKED"]),
              explanation: z.string(),
              sourceUrl: z.string(),
              sourceTitle: z.string(),
              retrievedAt: z.string(),
            })
          ),
          actionCard: z.unknown(),
          retrieval: z
            .object({
              sourceMode: z.enum([
                "live",
                "fallback",
                "live_unavailable_fallback",
                "demo",
              ]),
              result: z.enum([
                "success",
                "not_found",
                "blocked",
                "unavailable",
                "skipped",
              ]),
              queryValue: z.string().optional(),
              sourceUrl: z.string(),
              sourceTitle: z.string(),
              responseStatus: z.number().int().optional(),
              detail: z.string(),
              retrievedAt: z.string(),
              fallbackUsed: z.boolean(),
            })
            .optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const claims = normalizeClaims(input.claims);
        const id = await createVerificationCase({
          userId: ctx.user.id,
          title: input.title,
          language: input.language,
          sourceMode: input.sourceMode,
          extractedClaims: claims,
          actionCard: input.actionCard,
          status: "checked",
        });
        if (!id) return { id: null, saved: false };
        await addEvidenceChecks(
          id,
          input.evidence.map(row => ({
            caseId: id,
            field: row.field,
            claim: row.claim,
            status: row.status,
            explanation: row.explanation,
            sourceUrl: row.sourceUrl,
            sourceTitle: row.sourceTitle,
            retrievedAt: new Date(row.retrievedAt),
          }))
        );
        if (input.retrieval)
          await addSourceRetrieval({
            caseId: id,
            sourceMode: input.retrieval.sourceMode,
            result: input.retrieval.result,
            queryValue: input.retrieval.queryValue,
            sourceUrl: input.retrieval.sourceUrl,
            sourceTitle: input.retrieval.sourceTitle,
            responseStatus: input.retrieval.responseStatus,
            detail: input.retrieval.detail,
            retrievedAt: new Date(input.retrieval.retrievedAt),
          });
        return { id, saved: true };
      }),
    uploadDocument: protectedProcedure
      .input(
        z.object({
          caseId: z.number().int().positive(),
          fileName: z.string().max(255),
          mimeType: z.string().max(120),
          dataUrl: z.string().max(8_000_000),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const ownedCase = await getVerificationCase(ctx.user.id, input.caseId);
        if (!ownedCase) throw new Error("Case not found");
        const match = input.dataUrl.match(/^data:[^;]+;base64,(.+)$/);
        if (!match) throw new Error("Invalid document payload");
        const buffer = Buffer.from(match[1], "base64");
        const uploaded = await storagePut(
          `clearpath/${ctx.user.id}/${input.fileName}`,
          buffer,
          input.mimeType
        );
        const id = await addCaseDocument({
          caseId: input.caseId,
          userId: ctx.user.id,
          fileName: input.fileName,
          mimeType: input.mimeType,
          storageKey: uploaded.key,
          storageUrl: uploaded.url,
        });
        return { id, url: uploaded.url };
      }),
    deleteDocument: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => ({
        deleted: await deleteCaseDocument(ctx.user.id, input.id),
      })),
    deleteCase: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => ({
        deleted: await deleteVerificationCase(ctx.user.id, input.id),
      })),
  }),
});

export type AppRouter = typeof appRouter;
